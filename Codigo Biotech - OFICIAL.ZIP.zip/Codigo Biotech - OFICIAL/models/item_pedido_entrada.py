from core.database import Database
from datetime import datetime

class ItemPedidoEntrada:

    def __init__(self, produto_id_produto, qtd, preco_unitario, estoque_id_estoque):
        self.produto_id_produto = produto_id_produto
        self.qtd = qtd
        self.preco_unitario = preco_unitario
        self.estoque_id_estoque = estoque_id_estoque
        self.data_entrada = datetime.now()

    def insert(self):
        from models.movimentacao import Movimentacao  
        conexao = Database.connect()
        cursor = conexao.cursor()

        sql = """
        INSERT INTO Item_pedido_entrada
        (produto_id_produto, qtd, preco_unitario, data_entrada, estoque_id_estoque)
        VALUES (%s, %s, %s, %s, %s)
        """

        cursor.execute(sql, (
            self.produto_id_produto,
            self.qtd,
            self.preco_unitario,
            self.data_entrada,
            self.estoque_id_estoque
        ))

        conexao.commit()

        Movimentacao(
            tipo="ENTRADA",
            quantidade=self.qtd,
            observacao="Saída de item de pedido",
            data_movimentacao=self.data_entrada,
            produto=self.produto_id_produto
        ).insert()


        cursor.close()
        conexao.close()

    @classmethod
    def find_all(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        cursor.execute("""
            SELECT 
                i.idItem_pedido_entrada,
                p.nome,
                i.qtd,
                i.preco_unitario,
                i.data_entrada,
                i.estoque_id_estoque
            FROM Item_pedido_entrada i
            JOIN produto p ON p.idproduto = i.produto_id_produto
        """)

        dados = cursor.fetchall()

        cursor.close()
        conexao.close()

        return dados

    @classmethod
    def delete(cls, id):
        conexao = Database.connect()
        cursor = conexao.cursor()

        cursor.execute("""
            DELETE FROM Item_pedido_entrada
            WHERE idItem_pedido_entrada = %s
        """, (id,))

        conexao.commit()
        cursor.close()
        conexao.close()