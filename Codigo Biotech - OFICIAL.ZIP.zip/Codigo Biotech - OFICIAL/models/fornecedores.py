from core.crud_base import CrudBase
from core.validator import Validator

class Fornecedor(CrudBase):

    table = "fornecedor"
    pk = "id_fornecedor"

    fields = [
        "nome",
        "cnpj",
        "email"
    ]

    def __init__(self, nome=None, cnpj=None, email=None, id_fornecedor=None):
        self.id_fornecedor = id_fornecedor
        self.nome = nome
        self.cnpj = cnpj
        self.email = email

    def validate(self):
        erros = [
            Validator.required(self.nome, "Nome"),
            Validator.required(self.cnpj, "CNPJ"),
            Validator.required(self.email, "Email")
        ]

        return [e for e in erros if e]