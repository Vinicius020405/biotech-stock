from core.crud_base import CrudBase
from core.validator import Validator


class Cliente(CrudBase):

    table = "cliente"
    pk = "id_cliente"

    fields = [
        "nome",
        "cpf",
        "senha"
    ]

    def __init__(
        self,
        nome=None,
        cpf=None,
        senha=None,
        id_cliente=None
    ):
        self.id_cliente = id_cliente
        self.nome = nome
        self.cpf = cpf
        self.senha = senha

    def validate(self):

        erros = [
            Validator.required(
                self.nome,
                "nome"
            ),

            Validator.required(
                self.cpf,
                "cpf"
            ),

            Validator.required(
                self.senha,
                "senha"
            )
        ]

        return [erro for erro in erros if erro]

    @classmethod
    def has_related_records(cls, id):
        return False

    @classmethod
    def safe_delete(cls, id):

        cliente = cls.find_by_id(id)

        if not cliente:
            raise ValueError(
                "Cliente não encontrado."
            )

        if cls.has_related_records(id):
            raise ValueError(
                "Não é possível excluir o cliente pois possui registros vinculados."
            )

        cls.delete(id)