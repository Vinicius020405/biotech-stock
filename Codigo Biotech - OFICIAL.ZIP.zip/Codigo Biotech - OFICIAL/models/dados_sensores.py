from core.database import Database
from core.validator import Validator


class DadosSensores:

    table = "dados_sensores"
    pk = "id_dados_sensores"

    def __init__(self, tipo=None, descricao=None, sensores_id_sensores=None, id_dados_sensores=None):
        self.id_dados_sensores = id_dados_sensores
        self.tipo = tipo
        self.descricao = descricao
        self.sensores_id_sensores = sensores_id_sensores

    # =========================
    # VALIDATE
    # =========================
    def validate(self):
        erros = [
            Validator.required(self.tipo, "tipo"),
            Validator.required(self.descricao, "descricao"),
            Validator.required(self.sensores_id_sensores, "sensor")
        ]
        return [e for e in erros if e]

    # =========================
    # FIND ALL
    # =========================
    @classmethod
    def find_all(cls, order_by=None):
        conn = Database.connect()
        cursor = conn.cursor(dictionary=True)

        try:
            sql = "SELECT * FROM dados_sensores"

            if order_by:
                sql += f" ORDER BY {order_by}"

            cursor.execute(sql)
            return cursor.fetchall()

        finally:
            cursor.close()
            conn.close()

    # =========================
    # FIND BY ID
    # =========================
    @classmethod
    def find_by_id(cls, id):
        conn = Database.connect()
        cursor = conn.cursor(dictionary=True)

        try:
            cursor.execute(
                "SELECT * FROM dados_sensores WHERE id_dados_sensores = %s",
                (id,)
            )
            return cursor.fetchone()

        finally:
            cursor.close()
            conn.close()

    # =========================
    # INSERT
    # =========================
    def insert(self):
        conn = Database.connect()
        cursor = conn.cursor()

        try:
            cursor.execute(
                """
                INSERT INTO dados_sensores (tipo, descricao, sensores_id_sensores)
                VALUES (%s, %s, %s)
                """,
                (self.tipo, self.descricao, self.sensores_id_sensores)
            )
            conn.commit()

        finally:
            cursor.close()
            conn.close()

    # =========================
    # UPDATE
    # =========================
    def update(self, id):
        conn = Database.connect()
        cursor = conn.cursor()

        try:
            cursor.execute(
                """
                UPDATE dados_sensores
                SET tipo=%s,
                    descricao=%s,
                    sensores_id_sensores=%s
                WHERE id_dados_sensores=%s
                """,
                (self.tipo, self.descricao, self.sensores_id_sensores, id)
            )
            conn.commit()

        finally:
            cursor.close()
            conn.close()

    # =========================
    # DELETE
    # =========================
    @classmethod
    def delete(cls, id):
        conn = Database.connect()
        cursor = conn.cursor()

        try:
            cursor.execute(
                "DELETE FROM dados_sensores WHERE id_dados_sensores=%s",
                (id,)
            )
            conn.commit()

        finally:
            cursor.close()
            conn.close()