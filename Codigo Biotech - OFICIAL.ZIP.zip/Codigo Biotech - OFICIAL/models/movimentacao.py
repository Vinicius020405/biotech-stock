from core.database import Database
from datetime import datetime


class Movimentacao:

    def __init__(self, tipo, quantidade, observacao, data_movimentacao, produto):
        self.tipo = tipo
        self.quantidade = quantidade
        self.observacao = observacao
        self.data_movimentacao = data_movimentacao or datetime.now()
        self.produto = produto

    def insert(self):
        conn = Database.connect()
        cursor = conn.cursor()

        cursor.execute("""
        INSERT INTO movimentacao
        (tipo, quantidade, observacao, data_movimentacao, produto)
        VALUES (%s, %s, %s, %s, %s)
        """, (
            self.tipo,
            self.quantidade,
            self.observacao,
            self.data_movimentacao,
            self.produto
        ))

        conn.commit()
        cursor.close()
        conn.close()

    @classmethod
    def find_all(cls):   
        conn = Database.connect()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("""
            SELECT
                m.id_movimentacao,
                p.nome AS produto,
                c.nome AS cliente,
                m.tipo,
                m.quantidade,
                m.data_movimentacao

            FROM movimentacao m

            LEFT JOIN produto p
                ON p.idproduto = m.produto

            LEFT JOIN item_pedido_saida ips
                ON ips.id_item_pedido_saida =
                   m.item_pedido_saida_id_item_pedido_saida

            LEFT JOIN pedido_saida_cabecalho ps
                ON ps.item_pedido_saida_id_item_pedido_saida =
                   ips.id_item_pedido_saida

            LEFT JOIN cliente c
                ON c.id_cliente = ps.cliente_id_cliente

            ORDER BY m.id_movimentacao DESC
        """)

        dados = cursor.fetchall()

        cursor.close()
        conn.close()

        return dados