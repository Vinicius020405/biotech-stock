from core.database import Database
from models.movimentacao import Movimentacao

class ItemPedidoSaida:

    def __init__(self, produto_id_produto, qtd, preco_unitario, data, status, estoque_id_estoque):
        self.produto_id_produto = produto_id_produto
        self.qtd = qtd
        self.preco_unitario = preco_unitario
        self.data = data
        self.status = status
        self.estoque_id_estoque = estoque_id_estoque

    def insert(self):
        from models.movimentacao import Movimentacao  
        conexao = Database.connect()
        cursor = conexao.cursor()

        sql = """
        INSERT INTO item_pedido_saida
        (produto_id_produto, qtd, preco_unitario, data, status, estoque_id_estoque)
        VALUES (%s, %s, %s, %s, %s, %s)
        """

        cursor.execute(sql, (
            self.produto_id_produto,
            self.qtd,
            self.preco_unitario,
            self.data,
            self.status,
            self.estoque_id_estoque
        ))

        conexao.commit()

    
        Movimentacao(
            tipo="SAIDA",
            quantidade=self.qtd,
            observacao="Saída de item de pedido",
            data_movimentacao=self.data,
            produto=self.produto_id_produto
        ).insert()

        cursor.close()
        conexao.close()

    @classmethod
    def find_all(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        cursor.execute("""
            SELECT 
                s.id_item_pedido_saida,
                p.nome,
                s.qtd,
                s.preco_unitario,
                s.data,
                s.status,
                s.estoque_id_estoque
            FROM item_pedido_saida s
            JOIN produto p ON p.idproduto = s.produto_id_produto
        """)

        dados = cursor.fetchall()

        cursor.close()
        conexao.close()

        return dados

    @classmethod
    def find_by_id(cls, id):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        cursor.execute("""
            SELECT * FROM item_pedido_saida
            WHERE id_item_pedido_saida = %s
        """, (id,))

        dados = cursor.fetchone()

        cursor.close()
        conexao.close()

        return dados

    @classmethod
    def delete(cls, id):
        conexao = Database.connect()
        cursor = conexao.cursor()

        cursor.execute("""
            DELETE FROM item_pedido_saida
            WHERE id_item_pedido_saida = %s
        """, (id,))

        conexao.commit()
        cursor.close()
        conexao.close()