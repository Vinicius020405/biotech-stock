from core.crud_base import CrudBase
from core.database import Database
from core.validator import Validator


class Usuario(CrudBase):

    table = "usuario"
    pk = "id_usuario"

    fields = [
        "nome",
        "cpf",
        "senha",
        "email",
        "cargo",
        "admin"
    ]

    def __init__(
        self,
        nome=None,
        cpf=None,
        senha=None,
        email=None,
        cargo=None,
        admin=0,
        id_usuario=None
    ):
        self.id_usuario = id_usuario
        self.nome = nome
        self.cpf = cpf
        self.senha = senha
        self.email = email
        self.cargo = cargo
        self.admin = admin

    def validate(self):

        erros = [
            Validator.required(self.nome, "nome"),
            Validator.required(self.cpf, "cpf"),
            Validator.required(self.senha, "senha"),
            Validator.required(self.email, "email"),
            Validator.required(self.cargo, "cargo")
        ]

        return [erro for erro in erros if erro]

    @classmethod
    def has_related_records(cls, id):

        conexao = Database.connect()
        cursor = conexao.cursor()

        try:
            queries = [
                "SELECT COUNT(*) FROM movimentacao WHERE usuario_id = %s"
            ]

            total = 0

            for sql in queries:
                cursor.execute(sql, (id,))
                total += cursor.fetchone()[0]

            return total > 0

        except:
            return False

        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def safe_delete(cls, id):

        usuario = cls.find_by_id(id)

        if not usuario:
            raise ValueError("Usuário não encontrado.")

        if cls.has_related_records(id):
            raise ValueError(
                "Não é possível excluir o usuário pois possui registros vinculados."
            )

        cls.delete(id)