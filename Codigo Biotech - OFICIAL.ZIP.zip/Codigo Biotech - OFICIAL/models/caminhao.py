from core.database import Database
from core.crud_base import CrudBase
from core.validator import Validator


class Caminhao:

    def __init__(
        self,
        placa,
        modelo,
        cor,
        numero_serie,
        marca,
        chassi,
        localizacao_caminhao=None,
        caminhao_id=None
    ):
        self.caminhao_id = caminhao_id
        self.placa = placa
        self.modelo = modelo
        self.cor = cor
        self.numero_serie = numero_serie
        self.marca = marca
        self.chassi = chassi
        self.localizacao_caminhao = localizacao_caminhao

    def validate(self):

        erros = []

        if not self.placa:
            erros.append("Placa obrigatória")

        if not self.modelo:
            erros.append("Modelo obrigatório")

        if not self.marca:
            erros.append("Marca obrigatória")

        if not self.chassi:
            erros.append("Chassi obrigatório")

        return erros

    def insert(self):

        conexao = Database.connect()
        cursor = conexao.cursor()

        try:

            sql = """
            INSERT INTO caminhao (
                placa,
                modelo,
                cor,
                numero_serie,
                marca,
                chassi,
                localizacao_caminhao
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """

            cursor.execute(sql, (
                self.placa,
                self.modelo,
                self.cor,
                self.numero_serie,
                self.marca,
                self.chassi,
                self.localizacao_caminhao
            ))

            conexao.commit()

            return {
                "erro": False,
                "mensagem": "Caminhão cadastrado com sucesso!"
            }

        except Exception as e:

            conexao.rollback()

            return {
                "erro": True,
                "mensagem": str(e)
            }

        finally:

            cursor.close()
            conexao.close()

    def update(self, id):

        conexao = Database.connect()
        cursor = conexao.cursor()

        try:

            sql = """
            UPDATE caminhao SET
                placa=%s,
                modelo=%s,
                cor=%s,
                numero_serie=%s,
                marca=%s,
                chassi=%s,
                localizacao_caminhao=%s
            WHERE id_caminhao=%s
            """

            cursor.execute(sql, (
                self.placa,
                self.modelo,
                self.cor,
                self.numero_serie,
                self.marca,
                self.chassi,
                self.localizacao_caminhao,
                id
            ))

            conexao.commit()

            return {
                "erro": False,
                "mensagem": "Caminhão atualizado com sucesso!"
            }

        except Exception as e:

            conexao.rollback()

            return {
                "erro": True,
                "mensagem": str(e)
            }

        finally:

            cursor.close()
            conexao.close()

    @classmethod
    def delete(cls, id):

        conexao = Database.connect()
        cursor = conexao.cursor()

        try:

            # verifica vínculos
            cursor.execute("""
                SELECT COUNT(*)
                FROM pedido_saida_cabecalho
                WHERE caminhao_id_caminhao = %s
            """, (id,))

            total = cursor.fetchone()[0]

            if total > 0:

                return {
                    "erro": True,
                    "mensagem": "Não é possível excluir. Caminhão possui pedidos vinculados."
                }

            cursor.execute("""
                DELETE FROM caminhao
                WHERE id_caminhao = %s
            """, (id,))

            conexao.commit()

            return {
                "erro": False,
                "mensagem": "Caminhão excluído com sucesso!"
            }

        except Exception as e:

            conexao.rollback()

            return {
                "erro": True,
                "mensagem": str(e)
            }

        finally:

            cursor.close()
            conexao.close()

    @classmethod
    def find_all(cls):

        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        cursor.execute("""
            SELECT *
            FROM caminhao
        """)

        dados = cursor.fetchall()

        cursor.close()
        conexao.close()

        return dados

    @classmethod
    def find_by_id(cls, id):

        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        cursor.execute("""
            SELECT *
            FROM caminhao
            WHERE id_caminhao = %s
        """, (id,))

        dado = cursor.fetchone()

        cursor.close()
        conexao.close()

        return dado