from core.database import Database
from core.validator import Validator


class Sensor:
    table = "sensores"
    pk = "id_sensores"

    def __init__(self, localizacao_sensor=None, id_sensores=None):
        self.id_sensores = id_sensores
        self.localizacao_sensor = localizacao_sensor

    # =========================
    # VALIDATE (OBRIGATÓRIO)
    # =========================
    def validate(self):
        erros = []

        erro_local = Validator.required(
            self.localizacao_sensor,
            "localização do sensor"
        )

        if erro_local:
            erros.append(erro_local)

        return erros

    # =========================
    # FIND ALL
    # =========================
    @classmethod
    def find_all(cls, order_by=None):
        conn = Database.connect()
        cursor = conn.cursor(dictionary=True)

        try:
            sql = "SELECT * FROM sensores"

            if order_by:
                sql += f" ORDER BY {order_by}"

            cursor.execute(sql)
            return cursor.fetchall()

        finally:
            cursor.close()
            conn.close()

    # =========================
    # FIND BY ID
    # =========================
    @classmethod
    def find_by_id(cls, id_sensores):
        conn = Database.connect()
        cursor = conn.cursor(dictionary=True)

        try:
            cursor.execute(
                "SELECT * FROM sensores WHERE id_sensores = %s",
                (id_sensores,)
            )
            return cursor.fetchone()

        finally:
            cursor.close()
            conn.close()

    # =========================
    # INSERT
    # =========================
    def insert(self):
        conn = Database.connect()
        cursor = conn.cursor()

        try:
            cursor.execute(
                "INSERT INTO sensores (localizacao_sensor) VALUES (%s)",
                (self.localizacao_sensor,)
            )
            conn.commit()

        finally:
            cursor.close()
            conn.close()

    # =========================
    # UPDATE
    # =========================
    def update(self, id_sensores):
        conn = Database.connect()
        cursor = conn.cursor()

        try:
            cursor.execute(
                """
                UPDATE sensores
                SET localizacao_sensor = %s
                WHERE id_sensores = %s
                """,
                (self.localizacao_sensor, id_sensores)
            )
            conn.commit()

        finally:
            cursor.close()
            conn.close()

    # =========================
    # DELETE
    # =========================
    @classmethod
    def delete(cls, id_sensores):
        conn = Database.connect()
        cursor = conn.cursor()

        try:
            cursor.execute(
                "DELETE FROM sensores WHERE id_sensores = %s",
                (id_sensores,)
            )
            conn.commit()

        finally:
            cursor.close()
            conn.close()