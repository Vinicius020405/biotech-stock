from core.database import Database


class Produto:

    def __init__(self, nome, descricao, categoria, preco_custo, preco_venda,
                 tipo, data_validade, estoque, estoque_minimo,
                 unidade_medida, idproduto=None):

        self.idproduto = idproduto
        self.nome = nome
        self.descricao = descricao
        self.categoria = categoria
        self.preco_custo = preco_custo
        self.preco_venda = preco_venda
        self.tipo = tipo
        self.data_validade = data_validade
        self.estoque = estoque
        self.estoque_minimo = estoque_minimo
        self.unidade_medida = unidade_medida

    # ---------------- VALIDATION ----------------
    def validate(self):
        erros = []

        if not self.nome:
            erros.append("Nome obrigatório")
        if not self.categoria:
            erros.append("Categoria obrigatória")
        if self.preco_custo is None:
            erros.append("Preço custo obrigatório")
        if self.preco_venda is None:
            erros.append("Preço venda obrigatório")
        if not self.tipo:
            erros.append("Tipo obrigatório")
        if not self.data_validade:
            erros.append("Data validade obrigatória")
        if self.estoque is None:
            erros.append("Estoque obrigatório")

        return erros

    # ---------------- INSERT ----------------
    def insert(self):
        conn = Database.connect()
        cur = conn.cursor()

        cur.execute("""
            INSERT INTO produto (
                nome, descricao, categoria,
                preco_custo, preco_venda,
                tipo, data_validade,
                estoque, estoque_minimo,
                unidade_medida
            )
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """, (
            self.nome,
            self.descricao,
            self.categoria,
            self.preco_custo,
            self.preco_venda,
            self.tipo,
            self.data_validade,
            self.estoque,
            self.estoque_minimo,
            self.unidade_medida
        ))

        conn.commit()
        cur.close()
        conn.close()

    # ---------------- UPDATE ----------------
    def update(self, id):

        conn = Database.connect()
        cur = conn.cursor()

        cur.execute("""
            UPDATE produto SET
                nome=%s,
                descricao=%s,
                categoria=%s,
                preco_custo=%s,
                preco_venda=%s,
                tipo=%s,
                data_validade=%s,
                estoque=%s,
                estoque_minimo=%s,
                unidade_medida=%s
            WHERE idproduto=%s
        """, (
            self.nome,
            self.descricao,
            self.categoria,
            self.preco_custo,
            self.preco_venda,
            self.tipo,
            self.data_validade,
            self.estoque,
            self.estoque_minimo,
            self.unidade_medida,
            id
        ))

        conn.commit()
        cur.close()
        conn.close()

    # ---------------- DELETE ----------------
    @classmethod
    def delete(cls, id):
        conn = Database.connect()
        cur = conn.cursor()

        cur.execute("DELETE FROM produto WHERE idproduto=%s", (id,))

        conn.commit()
        cur.close()
        conn.close()

    # ---------------- FIND ALL ----------------
    @classmethod
    def find_all(cls):
        conn = Database.connect()
        cur = conn.cursor(dictionary=True)

        cur.execute("SELECT * FROM produto")
        dados = cur.fetchall()

        cur.close()
        conn.close()

        return dados

    # ---------------- FIND BY ID ----------------
    @classmethod
    def find_by_id(cls, id):
        conn = Database.connect()
        cur = conn.cursor(dictionary=True)

        cur.execute("SELECT * FROM produto WHERE idproduto=%s", (id,))
        dado = cur.fetchone()

        cur.close()
        conn.close()

        return dado