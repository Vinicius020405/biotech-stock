from core.database import Database


class PedidoSaida:

    def __init__(
        self,
        data,
        status,
        caminhao_id_caminhao,
        item_pedido_saida_id_item_pedido_saida,
        usuario_id_usuario,
        idproduto,
        cliente_id_cliente,
        qntd,
        id_pedido_saida_cabecalho=None
    ):

        self.id_pedido_saida_cabecalho = id_pedido_saida_cabecalho
        self.data = data
        self.status = status
        self.caminhao_id_caminhao = caminhao_id_caminhao
        self.item_pedido_saida_id_item_pedido_saida = item_pedido_saida_id_item_pedido_saida
        self.usuario_id_usuario = usuario_id_usuario
        self.cliente_id_cliente = cliente_id_cliente
        self.qntd = qntd
        self.idproduto = idproduto

    # ---------------- VALIDAR ---------------- #

    def validate(self):

        erros = []

        if not self.data:
            erros.append("Data obrigatória")

        if not self.status:
            erros.append("Status obrigatório")

        if not self.caminhao_id_caminhao:
            erros.append("Caminhão obrigatório")

        if not self.item_pedido_saida_id_item_pedido_saida:
            erros.append("Item do pedido obrigatório")

        if not self.usuario_id_usuario:
            erros.append("Usuário obrigatório")

        if not self.cliente_id_cliente:
            erros.append("Cliente obrigatório")

        if not self.qntd:
            erros.append("Quantidade obrigatória")

        if not self.idproduto:
            erros.append("Produto obrigatório")

        return erros

    # ---------------- INSERT ---------------- #

    def insert(self):

        from models.movimentacao import Movimentacao

        conn = Database.connect()
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO pedido_saida_cabecalho
            (
                data,
                status,
                caminhao_id_caminhao,
                item_pedido_saida_id_item_pedido_saida,
                usuario_id_usuario,
                cliente_id_cliente,
                qntd,
                idproduto
            )
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
        """, (
            self.data,
            self.status,
            self.caminhao_id_caminhao,
            self.item_pedido_saida_id_item_pedido_saida,
            self.usuario_id_usuario,
            self.cliente_id_cliente,
            self.qntd,
            self.idproduto
        ))

        conn.commit()

        id_gerado = cursor.lastrowid

        # cria movimentação automática
        Movimentacao(
            tipo="SAIDA",
            quantidade=self.qntd,
            observacao=f"Pedido saída #{id_gerado}",
            data_movimentacao=self.data,
            produto=self.idproduto
        ).insert()

        cursor.close()
        conn.close()

    # ---------------- UPDATE ---------------- #

    def update(self, id):

        conn = Database.connect()
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE pedido_saida_cabecalho
            SET
                data=%s,
                status=%s,
                caminhao_id_caminhao=%s,
                item_pedido_saida_id_item_pedido_saida=%s,
                usuario_id_usuario=%s,
                cliente_id_cliente=%s,
                qntd=%s,
                idproduto=%s
            WHERE id_pedido_saida_cabecalho=%s
        """, (
            self.data,
            self.status,
            self.caminhao_id_caminhao,
            self.item_pedido_saida_id_item_pedido_saida,
            self.usuario_id_usuario,
            self.cliente_id_cliente,
            self.qntd,
            self.idproduto,
            id
        ))

        conn.commit()

        cursor.close()
        conn.close()

    # ---------------- DELETE ---------------- #

    @classmethod
    def delete(cls, id):

        conn = Database.connect()
        cursor = conn.cursor()

        cursor.execute("""
            DELETE FROM pedido_saida_cabecalho
            WHERE id_pedido_saida_cabecalho = %s
        """, (id,))

        conn.commit()

        cursor.close()
        conn.close()

    # ---------------- FIND ALL ---------------- #

    @classmethod
    def find_all(cls):

        conn = Database.connect()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("""
            SELECT *
            FROM pedido_saida_cabecalho
            ORDER BY id_pedido_saida_cabecalho DESC
        """)

        dados = cursor.fetchall()

        cursor.close()
        conn.close()

        return dados

    # ---------------- FIND BY ID ---------------- #

    @classmethod
    def find_by_id(cls, id):

        conn = Database.connect()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("""
            SELECT *
            FROM pedido_saida_cabecalho
            WHERE id_pedido_saida_cabecalho = %s
        """, (id,))

        dado = cursor.fetchone()

        cursor.close()
        conn.close()

        return dado