from core.database import Database
from datetime import datetime


class PedidoEntrada:

    def __init__(
        self,
        criacao_pedido,
        cliente,
        tipo,
        qntd,
        usuario_id_usuario,
        data_entrada,
        idproduto,
        idcabecalho_ped_entrada=None
    ):

        self.idcabecalho_ped_entrada = idcabecalho_ped_entrada
        self.criacao_pedido = criacao_pedido
        self.cliente = cliente
        self.tipo = tipo
        self.qntd = qntd
        self.usuario_id_usuario = usuario_id_usuario
        self.data_entrada = data_entrada
        self.idproduto = idproduto

    # ---------------- VALIDAR ---------------- #

    def validate(self):

        erros = []

        if not self.criacao_pedido:
            erros.append("Data de criação obrigatória")

        if not self.cliente:
            erros.append("Cliente obrigatório")

        if not self.tipo:
            erros.append("Tipo obrigatório")

        if not self.qntd:
            erros.append("Quantidade obrigatória")

        if not self.usuario_id_usuario:
            erros.append("Usuário obrigatório")

        if not self.data_entrada:
            erros.append("Data entrada obrigatória")

        if not self.idproduto:
            erros.append("Produto obrigatório")

        return erros

    # ---------------- INSERT ---------------- #

    def insert(self):

        from models.movimentacao import Movimentacao

        conn = Database.connect()
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO cabecalho_ped_entrada
            (
                criacao_pedido,
                cliente,
                tipo,
                qntd,
                usuario_id_usuario,
                idproduto,
                data_entrada
            )
            VALUES (%s,%s,%s,%s,%s,%s,%s)
        """, (
            self.criacao_pedido,
            self.cliente,
            self.tipo,
            self.qntd,
            self.usuario_id_usuario,
            self.idproduto,
            self.data_entrada
        ))

        conn.commit()

        id_gerado = cursor.lastrowid

        # cria movimentação automática
        Movimentacao(
            tipo="ENTRADA",
            quantidade=self.qntd,
            observacao=f"Pedido entrada #{id_gerado}",
            data_movimentacao=self.data_entrada,
            produto=self.idproduto
        ).insert()

        cursor.close()
        conn.close()

    # ---------------- UPDATE ---------------- #

    def update(self, id):

        conn = Database.connect()
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE cabecalho_ped_entrada
            SET
                criacao_pedido=%s,
                cliente=%s,
                tipo=%s,
                qntd=%s,
                usuario_id_usuario=%s,
                data_entrada=%s,
                idproduto=%s
            WHERE idcabecalho_ped_entrada=%s
        """, (
            self.criacao_pedido,
            self.cliente,
            self.tipo,
            self.qntd,
            self.usuario_id_usuario,
            self.data_entrada,
            self.idproduto,
            id
        ))

        conn.commit()

        cursor.close()
        conn.close()

    # ---------------- DELETE ---------------- #

    @classmethod
    def delete(cls, id):

        conn = Database.connect()
        cursor = conn.cursor()

        cursor.execute("""
            DELETE FROM cabecalho_ped_entrada
            WHERE idcabecalho_ped_entrada = %s
        """, (id,))

        conn.commit()

        cursor.close()
        conn.close()

    # ---------------- FIND ALL ---------------- #

    @classmethod
    def find_all(cls):

        conn = Database.connect()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("""
            SELECT
                idcabecalho_ped_entrada AS id,
                criacao_pedido,
                cliente,
                tipo,
                qntd,
                usuario_id_usuario,
                idproduto,
                data_entrada
            FROM cabecalho_ped_entrada
            ORDER BY idcabecalho_ped_entrada DESC
        """)

        dados = cursor.fetchall()

        cursor.close()
        conn.close()

        return dados

    # ---------------- FIND BY ID ---------------- #

    @classmethod
    def find_by_id(cls, id):

        conn = Database.connect()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("""
            SELECT
                idcabecalho_ped_entrada AS id,
                criacao_pedido,
                cliente,
                tipo,
                qntd,
                usuario_id_usuario,
                idproduto,
                data_entrada
            FROM cabecalho_ped_entrada
            WHERE idcabecalho_ped_entrada = %s
        """, (id,))

        dados = cursor.fetchone()

        cursor.close()
        conn.close()

        return dados