
#------------------ importar de cada tabela o nome da classe para "linkar"------------#

from flask import Flask, render_template, request, redirect, url_for, flash
from models.produto import Produto
from models.movimentacao import Movimentacao
from models.pedido_movimentacao import PedidoMovimentacao
from models.fornecedores import Fornecedor
from models.sensor import Sensor
from models.clientes import Cliente
from models.caminhao import Caminhao
from models.usuario import Usuario
from models.cabecalho_ped_entrada import PedidoEntrada
from models.cabecalho_ped_saida import PedidoSaida
from models.item_pedido_entrada import ItemPedidoEntrada
from models.item_pedido_saida import ItemPedidoSaida
from models.dados_sensores import DadosSensores
from models.estoque import Estoque
from core.database import Database




app = Flask(__name__)
app.secret_key = "chave_secreta"

#--------------- Definir as funções de cada tabela-----------#


def to_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def to_float(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def get_produto():
    return {
        "nome_produto": request.form.get("nome_produto"),
        "categoria": request.form.get("categoria"),
        "preco_custo": request.form.get("preco_custo"),
        "preco_venda": request.form.get("preco_venda"),
        "tipo": request.form.get("tipo"),
        "data_validade": request.form.get("data_validade"),
        "estoque_id_estoque": request.form.get("estoque_id_estoque"),
        "descricao": request.form.get("descricao"),
        "unidade_medida": request.form.get("unidade_medida")
    }



def get_pedido_entrada():
    return {
        "criacao_pedido": request.form.get("criacao_pedido"),
        "cliente": request.form.get("cliente"),
        "tipo": request.form.get("tipo"),
        "qntd": request.form.get("qntd"),
        "usuario_id_usuario": request.form.get("usuario_id_usuario"),
        "data_entrada": request.form.get("data_entrada"),
        "idproduto" : request.form.get("idproduto")
    }

def get_estoque():
    return {
        "dados_sensores_id_dados_sensores": request.form.get("dados_sensores_id_dados_sensores"),
        "quantidade_atual": request.form.get("quantidade_atual"),
        "quantidade_minima": request.form.get("quantidade_minima"),
        "quantidade_maxima": request.form.get("quantidade_maxima"),
    }


def get_pedido_saida():
    return {
        "data": request.form.get("data"),
        "status": request.form.get("status"),
        "caminhao_id_caminhao": request.form.get("caminhao_id_caminhao"),
        "item_pedido_saida_id_item_pedido_saida": request.form.get("item_pedido_saida_id_item_pedido_saida"),
        "usuario_id_usuario": request.form.get("usuario_id_usuario"),
        "cliente_id_cliente": request.form.get("cliente_id_cliente"),
        "qntd": request.form.get("qntd"),
        "idproduto" : request.form.get("idproduto")
    }



def get_fornecedor():
    return {
        "fornecedor_id": to_int(request.form.get("produto_id")),
        "nome": request.form.get("nome","").strip().upper(),
        "cnpj": request.form.get("cnpj", "").strip().upper(),
        "email":request.form.get("email","").strip().upper()
    }

def get_sensor():
    return {
        "localizacao_sensor": request.form.get(
            "localizacao_sensor", ""
        ).strip().upper()
    }
def get_dados_sensores():
    return {
        "tipo": request.form.get("tipo", "").strip().upper(),
        "descricao": request.form.get("descricao", "").strip().upper(),
        "sensores_id_sensores": request.form.get("sensores_id_sensores")
    }

def get_cliente():
    return {
        "nome": request.form.get(
            "nome", ""
        ).strip().upper(),

        "cpf": request.form.get(
            "cpf", ""
        ).strip(),

        "senha": request.form.get(
            "senha", ""
        ).strip()
    }


def get_caminhao():
    return {
        "placa": request.form.get("placa", "").strip().upper(),
        "modelo": request.form.get("modelo", "").strip().upper(),
        "cor": request.form.get("cor", "").strip().upper(),
        "marca": request.form.get("marca", "").strip().upper(),
        "chassi": request.form.get("chassi", "").strip().upper(),
    }

def get_usuario():
    return {
        "nome": request.form.get("nome", "").strip().upper(),
        "cpf": request.form.get("cpf", "").strip(),
        "senha": request.form.get("senha", "").strip(),
        "email": request.form.get("email", "").strip().lower(),
        "cargo": request.form.get("cargo", "").strip().upper(),
        "admin": to_int(request.form.get("admin")) or 0
    }

def get_cabecalho_pedido_entrada():
    return {
        "id_cabecalho_pedido_entrada":to_int(request.form.get("id_cabecalho_pedido_entrada")),
        "data_criacao": datetime(request.form.get("data_criacao")),
        "tipo": request.form.get("tipo","").strip().upper(),
        "qntd": to_int(request.form.get("qntd")),
        "data_entrada": datetime(request.form.get("data_entrada"))
    }




@app.route("/")
def index():
    produtos_baixo = Estoque.find_all()
    return render_template("index.html", produtos_baixo=produtos_baixo)




#----------------------------PRODUTOS------------------------#

# ---------------- LISTAR ----------------
@app.route('/produtos')
def listar_produtos():
    produtos = Produto.find_all()
    return render_template('produtos.html', produtos=produtos)


# ---------------- NOVO FORM ----------------
@app.route('/produto/novo')
def novo_produto():
    return render_template('formulario_produto.html', produto=None)


# ---------------- SALVAR ----------------
@app.route('/produto/salvar', methods=['POST'])
def salvar_produto():

    dados = request.form

    produto = Produto(
        nome=dados.get('nome'),
        descricao=dados.get('descricao'),
        categoria=dados.get('categoria'),
        preco_custo=dados.get('preco_custo'),
        preco_venda=dados.get('preco_venda'),
        tipo=dados.get('tipo'),
        data_validade=dados.get('data_validade'),
        estoque=dados.get('estoque'),
        estoque_minimo=dados.get('estoque_minimo'),
        unidade_medida=dados.get('unidade_medida')
    )

    erros = produto.validate()

    if erros:
        return render_template('formulario_produto.html', produto=dados, erros=erros)

    produto.insert()

    return redirect(url_for('listar_produtos'))


# ---------------- EDITAR ----------------
@app.route('/produto/editar/<int:id>')
def editar_produto(id):

    produto = Produto.find_by_id(id)

    return render_template('formulario_produto.html', produto=produto)


# ---------------- ATUALIZAR ----------------
@app.route('/produto/atualizar/<int:id>', methods=['POST'])
def atualizar_produto(id):

    dados = request.form

    produto = Produto(
        nome=dados.get('nome'),
        descricao=dados.get('descricao'),
        categoria=dados.get('categoria'),
        preco_custo=dados.get('preco_custo'),
        preco_venda=dados.get('preco_venda'),
        tipo=dados.get('tipo'),
        data_validade=dados.get('data_validade'),
        estoque=dados.get('estoque'),
        estoque_minimo=dados.get('estoque_minimo'),
        unidade_medida=dados.get('unidade_medida')
    )

    erros = produto.validate()

    if erros:
        return render_template('formulario_produto.html', produto=dados, erros=erros)

    produto.update(id)

    return redirect(url_for('listar_produtos'))


# ---------------- EXCLUIR ----------------
@app.route('/produto/excluir/<int:id>')
def excluir_produto(id):

    Produto.delete(id)

    return redirect(url_for('listar_produtos'))






#----------------------- PEDIDO--------------------#

@app.route("/pedidos")
def pedidos():
    return render_template("pedidos.html", pedidos=PedidoMovimentacao.find_all_with_product())


@app.route("/pedido/novo/<tipo>/<int:produto_id>")
def novo_pedido(tipo, produto_id):
    produto = Produto.find_by_id(produto_id)
    tipo = tipo.upper()

    if not produto:
        flash("Produto não encontrado.", "erro")
        return redirect(url_for("produtos"))

    if tipo not in ["ENTRADA", "SAIDA"]:
        flash("Tipo de pedido inválido.", "erro")
        return redirect(url_for("produtos"))

    return render_template("formulario_pedido.html", produto=produto, tipo=tipo, pedido=None)


@app.route("/pedido/salvar", methods=["POST"])
def salvar_pedido():
    dados = get_pedido_entrada()
    produto = Produto.find_by_id(dados["produto_id"])
    pedido = PedidoMovimentacao(**dados)
    erros = pedido.validate()

    if not produto:
        flash("Produto não encontrado.", "erro")
        return redirect(url_for("produtos"))

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("formulario_pedido.html", produto=produto, tipo=dados["tipo"], pedido=dados)

    try:
        pedido.insert()
        flash("Pedido criado com sucesso.", "sucesso")
        return redirect(url_for("pedidos"))
    except Exception as e:
        flash(f"Erro ao criar pedido: {e}", "erro")
        return render_template("formulario_pedido.html", produto=produto, tipo=dados["tipo"], pedido=dados)
    

@app.route("/pedido/processar/<int:id>")
def processar_pedido(id):
    try:
        mensagem = PedidoMovimentacao.processar(id)
        flash(mensagem, "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao processar pedido: {e}", "erro")
    return redirect(url_for("pedidos"))


@app.route("/pedido/cancelar/<int:id>")
def cancelar_pedido(id):
    try:
        mensagem = PedidoMovimentacao.cancelar(id)
        flash(mensagem, "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao cancelar pedido: {e}", "erro")
    return redirect(url_for("pedidos"))













#---------------------------- MOVIMENTAÇÃO----------------------#

@app.route("/movimentacoes")
def listar_movimentacoes():
    from models.movimentacao import Movimentacao

    return render_template(
        "movimentacoes.html",
        movimentacoes=Movimentacao.find_all()
    )
#----------------- FORNECEDOR -----------------#

@app.route("/fornecedor")
def listar_fornecedores():
    return render_template(
        "fornecedor.html",
        fornecedores=Fornecedor.find_all(order_by="nome"),
        fornecedor=None
    )


@app.route("/fornecedor/novo")
def novo_fornecedor():
    return render_template(
        "formulario_fornecedor.html",
        fornecedores=Fornecedor.find_all(order_by="nome"),
        fornecedor=None
    )


def get_fornecedor():
    return {
        "nome": request.form.get("nome"),
        "cnpj": request.form.get("cnpj"),
        "email": request.form.get("email")
    }


@app.route("/fornecedor/salvar", methods=["POST"])
def salvar_fornecedor():

    dados = get_fornecedor()
    fornecedor = Fornecedor(**dados)

    erros = fornecedor.validate()

    if erros:
        for e in erros:
            flash(e, "erro")

        return render_template(
            "formulario_fornecedor.html",
            fornecedores=Fornecedor.find_all(order_by="nome"),
            fornecedor=dados
        )

    fornecedor.insert()

    flash("Fornecedor cadastrado com sucesso!", "sucesso")
    return redirect(url_for("listar_fornecedores"))


@app.route("/fornecedor/editar/<int:id>")
def editar_fornecedor(id):

    fornecedor = Fornecedor.find_by_id(id)

    return render_template(
        "formulario_fornecedor.html",
        fornecedores=Fornecedor.find_all(order_by="nome"),
        fornecedor=fornecedor
    )


@app.route("/fornecedor/atualizar/<int:id>", methods=["POST"])
def atualizar_fornecedor(id):

    dados = get_fornecedor()
    fornecedor = Fornecedor(**dados)

    fornecedor.update(id)

    flash("Fornecedor atualizado com sucesso!", "sucesso")

    return redirect(url_for("listar_fornecedores"))


@app.route("/fornecedor/excluir/<int:id>")
def excluir_fornecedor(id):

    Fornecedor.delete(id)

    flash("Fornecedor excluído com sucesso!", "sucesso")

    return redirect(url_for("listar_fornecedores"))








#--------- SENSOR ---------------#    
@app.route("/sensor")
def listar_sensores():
    return render_template(
        "sensor.html",
        sensores=Sensor.find_all(order_by="localizacao_sensor")
    )


@app.route("/sensor/novo")
def novo_sensor():
    return render_template("formulario_sensor.html", sensor=None)


@app.route("/sensor/salvar", methods=["POST"])
def salvar_sensor():
    dados = get_sensor()
    sensor = Sensor(**dados)

    erros = sensor.validate()   # ✔ CORRETO

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("formulario_sensor.html", sensor=dados)

    try:
        sensor.insert()
        flash("Sensor cadastrado com sucesso.", "sucesso")
        return redirect(url_for("listar_sensores"))

    except Exception as e:
        flash(f"Erro ao cadastrar sensor: {e}", "erro")
        return render_template("formulario_sensor.html", sensor=dados)


@app.route("/sensor/editar/<int:id>")
def editar_sensor(id):
    sensor = Sensor.find_by_id(id)

    if not sensor:
        flash("Sensor não encontrado.", "erro")
        return redirect(url_for("listar_sensores"))

    return render_template("formulario_sensor.html", sensor=sensor)


@app.route("/sensor/atualizar/<int:id>", methods=["POST"])
def atualizar_sensor(id):
    dados = get_sensor()
    sensor = Sensor(**dados)

    erros = sensor.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")

        dados["id_sensores"] = id   
        return render_template("formulario_sensor.html", sensor=dados)

    try:
        if not Sensor.find_by_id(id):
            flash("Sensor não encontrado.", "erro")
            return redirect(url_for("listar_sensores"))

        sensor.update(id)

        flash("Sensor atualizado com sucesso.", "sucesso")
        return redirect(url_for("listar_sensores"))

    except Exception as e:
        dados["id_sensores"] = id   # ✔ CORRIGIDO
        flash(f"Erro ao atualizar sensor: {e}", "erro")
        return render_template("formulario_sensor.html", sensor=dados)


@app.route("/sensor/excluir/<int:id>")
def excluir_sensor(id):
    sensor = Sensor.find_by_id(id)

    if not sensor:
        flash("Sensor não encontrado.", "erro")
        return redirect(url_for("listar_sensores"))

    Sensor.delete(id)

    flash("Sensor excluído com sucesso.", "sucesso")
    return redirect(url_for("listar_sensores"))







#---------------CLIENTE------------------#


@app.route("/cliente")
def listar_clientes():

    return render_template(
        "clientes.html",
        clientes=Cliente.find_all(order_by="nome")
    )


@app.route("/cliente/novo")
def novo_cliente():

    return render_template(
        "formulario_cliente.html",
        cliente=None
    )


@app.route("/cliente/salvar", methods=["POST"])
def salvar_cliente():

    dados = get_cliente()

    cliente = Cliente(**dados)

    erros = cliente.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")

        return render_template(
            "formulario_cliente.html",
            cliente=dados
        )

    try:

        cliente.insert()

        flash(
            "Cliente cadastrado com sucesso.",
            "sucesso"
        )

        return redirect(
            url_for("listar_clientes")
        )

    except Exception as e:

        flash(
            f"Erro ao cadastrar cliente: {e}",
            "erro"
        )

        return render_template(
            "formulario_cliente.html",
            cliente=dados
        )


@app.route("/cliente/editar/<int:id>")
def editar_cliente(id):

    cliente = Cliente.find_by_id(id)

    if not cliente:
        flash("Cliente não encontrado.", "erro")

        return redirect(
            url_for("listar_clientes")
        )

    return render_template(
        "formulario_cliente.html",
        cliente=cliente
    )


@app.route("/cliente/atualizar/<int:id>", methods=["POST"])
def atualizar_cliente(id):

    dados = get_cliente()

    cliente = Cliente(**dados)

    erros = cliente.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")

        dados["id_cliente"] = id

        return render_template(
            "formulario_cliente.html",
            cliente=dados
        )

    try:

        if not Cliente.find_by_id(id):
            flash("Cliente não encontrado.", "erro")

            return redirect(
                url_for("listar_clientes")
            )

        cliente.update(id)

        flash(
            "Cliente atualizado com sucesso.",
            "sucesso"
        )

        return redirect(
            url_for("listar_clientes")
        )

    except Exception as e:

        dados["id_cliente"] = id

        flash(
            f"Erro ao atualizar cliente: {e}",
            "erro"
        )

        return render_template(
            "formulario_cliente.html",
            cliente=dados
        )


@app.route("/cliente/excluir/<int:id>")
def excluir_cliente(id):

    try:

        Cliente.safe_delete(id)

        flash(
            "Cliente excluído com sucesso.",
            "sucesso"
        )

    except ValueError as e:

        flash(str(e), "erro")

    except Exception as e:

        flash(
            f"Erro ao excluir cliente: {e}",
            "erro"
        )

    return redirect(
        url_for("listar_clientes")
    )


# --------- USUARIO ---------------#

@app.route("/usuario")
def listar_usuario():
    return render_template(
        "usuario.html",
        usuarios=Usuario.find_all(order_by="nome"),
        usuario=None
    )


@app.route("/usuario/novo")
def novo_usuario():
    return render_template(
        "formulario_usuario.html",
        usuario=None
    )




@app.route("/usuario/salvar", methods=["POST"])
def salvar_usuario():

    dados = get_usuario()
    usuario = Usuario(**dados)

    erros = usuario.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")

        return render_template(
            "formulario_usuario.html",
            usuarios=Usuario.find_all(order_by="nome"),
            usuario=dados
        )

    try:
        usuario.insert()

        flash("Usuário cadastrado com sucesso.", "sucesso")
        return redirect(url_for("listar_usuario"))

    except Exception as e:

        flash(f"Erro ao cadastrar usuário: {e}", "erro")

        return render_template(
            "formulario_usuario.html",
            usuarios=Usuario.find_all(order_by="nome"),
            usuario=dados
        )


@app.route("/usuario/editar/<int:id>")
def editar_usuario(id):

    usuario = Usuario.find_by_id(id)

    if not usuario:
        flash("Usuário não encontrado.", "erro")
        return redirect(url_for("listar_usuario"))

    return render_template(
        "formulario_usuario.html",
        usuarios=Usuario.find_all(order_by="nome"),
        usuario=usuario
    )


@app.route("/usuario/atualizar/<int:id>", methods=["POST"])
def atualizar_usuario(id):

    dados = get_usuario()
    usuario = Usuario(**dados)

    erros = usuario.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")

        dados["id_usuario"] = id

        return render_template(
            "formulario_usuario.html",
            usuarios=Usuario.find_all(order_by="nome"),
            usuario=dados
        )

    try:
        if not Usuario.find_by_id(id):
            flash("Usuário não encontrado.", "erro")
            return redirect(url_for("listar_usuario"))

        usuario.update(id)

        flash("Usuário atualizado com sucesso.", "sucesso")
        return redirect(url_for("listar_usuario"))

    except Exception as e:

        dados["id_usuario"] = id

        flash(f"Erro ao atualizar usuário: {e}", "erro")

        return render_template(
            "formulario_usuario.html",
            usuarios=Usuario.find_all(order_by="nome"),
            usuario=dados
        )


@app.route("/usuario/excluir/<int:id>")
def excluir_usuario(id):

    try:
        Usuario.delete(id)
        flash("Usuário excluído com sucesso.", "sucesso")

    except Exception as e:
        flash(f"Erro ao excluir usuário: {e}", "erro")

    return redirect(url_for("listar_usuario"))

    
#-------------- CAMINHAO----------------



@app.route("/caminhao")
def listar_caminhoes():
    return render_template(
        "caminhao.html",
        caminhoes=Caminhao.find_all()
    )

@app.route("/caminhao/novo")
def novo_caminhao():
    return render_template(
        "formulario_caminhao.html",
        caminhao=None
    )

def get_caminhao():
    return {
        "placa": request.form.get("placa"),
        "modelo": request.form.get("modelo"),
        "cor": request.form.get("cor"),
        "marca": request.form.get("marca"),
        "chassi": request.form.get("chassi"),
        "numero_serie": request.form.get("numero_serie"),
        "localizacao_caminhao": request.form.get("localizacao_caminhao")
    }

@app.route("/caminhao/salvar", methods=["POST"])
def salvar_caminhao():

    dados = get_caminhao()
    caminhao = Caminhao(**dados)

    erros = caminhao.validate()
    if erros:
        for e in erros:
            flash(e, "erro")
        return render_template("formulario_caminhao.html", caminhao=dados)

    try:
        caminhao.insert()
        flash("Caminhão cadastrado com sucesso!", "sucesso")
        return redirect(url_for("listar_caminhoes"))

    except Exception as e:
        flash(f"Erro ao salvar: {e}", "erro")
        return render_template("formulario_caminhao.html", caminhao=dados)


@app.route("/caminhao/editar/<int:id>")
def editar_caminhao(id):

    caminhao = Caminhao.find_by_id(id)

    if not caminhao:
        flash("Caminhão não encontrado", "erro")
        return redirect(url_for("listar_caminhoes"))

    return render_template(
        "formulario_caminhao.html",
        caminhao=caminhao
    )



@app.route("/caminhao/atualizar/<int:id>", methods=["POST"])
def atualizar_caminhao(id):

    dados = get_caminhao()
    caminhao = Caminhao(**dados)

    erros = caminhao.validate()
    if erros:
        for e in erros:
            flash(e, "erro")
        dados["id_caminhao"] = id
        return render_template("formulario_caminhao.html", caminhao=dados)

    try:
        caminhao.update(id)
        flash("Caminhão atualizado com sucesso!", "sucesso")
        return redirect(url_for("listar_caminhoes"))

    except Exception as e:
        dados["id_caminhao"] = id
        flash(f"Erro ao atualizar: {e}", "erro")
        return render_template("formulario_caminhao.html", caminhao=dados)


@app.route("/caminhao/excluir/<int:id>")
def excluir_caminhao(id):

    resultado = Caminhao.delete(id)

    if resultado["erro"]:
        flash(resultado["mensagem"], "erro")
    else:
        flash(resultado["mensagem"], "sucesso")

    return redirect(url_for("listar_caminhoes"))



#----------------- ESTOQUE ------------#


@app.route("/estoque")
def listar_estoque():
    return render_template(
        "estoque.html",
        estoques=Estoque.find_all()
    )


@app.route("/estoque/novo")
def novo_estoque():
    sensores = DadosSensores.find_all()

    return render_template(
        "formulario_estoque.html",
        estoque=None,
        sensores=sensores
    )


@app.route("/estoque/salvar", methods=["POST"])
def salvar_estoque():

    dados = get_estoque()
    estoque = Estoque(**dados)

    erros = estoque.validate()
    if erros:
        for e in erros:
            flash(e, "erro")

        sensores = DadosSensores.find_all()
        return render_template(
            "formulario_estoque.html",
            estoque=Estoque(**dados),
            sensores=sensores
        )

    try:
        estoque.insert()
        flash("Estoque cadastrado com sucesso!", "sucesso")
        return redirect(url_for("listar_estoque"))

    except Exception as e:
        flash(f"Erro ao salvar: {e}", "erro")

        sensores = DadosSensores.find_all()
        return render_template(
            "formulario_estoque.html",
            estoque=Estoque(**dados),
            sensores=sensores
        )


@app.route("/estoque/editar/<int:id>")
def editar_estoque(id):

    dados = Estoque.find_by_id(id)
    sensores = DadosSensores.find_all()

    if not dados:
        flash("Estoque não encontrado", "erro")
        return redirect(url_for("listar_estoque"))

    estoque = Estoque(**dados)

    return render_template(
        "formulario_estoque.html",
        estoque=estoque,
        sensores=sensores
    )


@app.route("/estoque/atualizar/<int:id>", methods=["POST"])
def atualizar_estoque(id):

    dados = get_estoque()
    estoque = Estoque(**dados)

    erros = estoque.validate()
    if erros:
        for e in erros:
            flash(e, "erro")

        sensores = DadosSensores.find_all()
        dados["id_estoque"] = id

        return render_template(
            "formulario_estoque.html",
            estoque=Estoque(**dados),
            sensores=sensores
        )

    try:
        estoque.update(id)
        flash("Estoque atualizado com sucesso!", "sucesso")
        return redirect(url_for("listar_estoque"))

    except Exception as e:
        flash(f"Erro ao atualizar: {e}", "erro")

        sensores = DadosSensores.find_all()
        dados["id_estoque"] = id

        return render_template(
            "formulario_estoque.html",
            estoque=Estoque(**dados),
            sensores=sensores
        )


@app.route("/estoque/excluir/<int:id>")
def excluir_estoque(id):

    try:
        Estoque.delete(id)
        flash("Estoque excluído com sucesso!", "sucesso")

    except Exception as e:
        flash(f"Erro ao excluir: {e}", "erro")

    return redirect(url_for("listar_estoque"))


#------------------- PEDIDO ENTRADA --------------------#

@app.route("/pedido-entrada")
def listar_pedido_entrada():
    return render_template(
        "pedido_entrada.html",
        pedidos=PedidoEntrada.find_all()
    )


@app.route("/pedido-entrada/novo")
def novo_pedido_entrada():
    return render_template(
        "formulario_pedido_entrada.html",
        pedido=None
    )

@app.route("/pedido-entrada/salvar", methods=["POST"])
def salvar_pedido_entrada():

    dados = get_pedido_entrada()
    pedido = PedidoEntrada(**dados)

    erros = pedido.validate()
    if erros:
        for e in erros:
            flash(e, "erro")
        return render_template("pedido_entrada.html",pedido=dados)

    try:   
        pedido.insert()
        flash("Salvo com sucesso!", "sucesso")
        return redirect(url_for("listar_pedido_entrada"))

    except Exception as e:
        flash(f"Erro ao salvar: {e}", "erro")
        return render_template("pedido_entrada.html", pedido=dados)


@app.route("/pedido-entrada/editar/<int:id>")
def editar_pedido_entrada(id):

    pedido = PedidoEntrada.find_by_id(id)

    if not pedido:
        flash("Não encontrado", "erro")
        return redirect(url_for("listar_pedido_entrada"))

    return render_template(
        "formulario_pedido_entrada.html",
        pedido=pedido
    )


@app.route("/pedido-entrada/atualizar/<int:id>", methods=["POST"])
def atualizar_pedido_entrada(id):

    dados = get_pedido_entrada()
    pedido = PedidoEntrada(**dados)
    erros = pedido.validate()

    if erros:
        for e in erros:
            flash(e, "erro")
        dados["id"] = id
        return render_template(
            "formulario_pedido_entrada.html",
            pedido=dados
        )

    pedido.update(id)
    flash("Atualizado com sucesso!", "sucesso")
    return redirect(url_for("listar_pedido_entrada"))

@app.route("/pedido-entrada/excluir/<int:id>")
def excluir_pedido_entrada(id):
    conn = Database.connect()
    cursor = conn.cursor()

    cursor.execute(
        "DELETE FROM cabecalho_ped_entrada WHERE idcabecalho_ped_entrada = %s",
        (id,)
    )

    conn.commit()
    cursor.close()
    conn.close()

    flash("Excluído com sucesso!", "sucesso")
    return redirect(url_for("listar_pedido_entrada"))



    

#------------------------ PEDIDO SAIDA ------------------#
@app.route("/pedido-saida")
def listar_pedido_saida():
    return render_template(
        "pedido_saida.html",
        pedidos=PedidoSaida.find_all()
    )


@app.route("/pedido-saida/novo")
def novo_pedido_saida():
    return render_template(
        "formulario_pedido_saida.html",
        pedido=None
    )


@app.route("/pedido-saida/salvar", methods=["POST"])
def salvar_pedido_saida():

    dados = get_pedido_saida()
    pedido = PedidoSaida(**dados)

    try:
        pedido.insert()
        flash("Salvo com sucesso!", "sucesso")
        return redirect(url_for("listar_pedido_saida"))

    except Exception as e:
        flash(f"Erro: {e}", "erro")
        return render_template("formulario_pedido_saida.html", pedido=dados)


@app.route("/pedido-saida/editar/<int:id>")
def editar_pedido_saida(id):

    pedido = PedidoSaida.find_by_id(id)

    return render_template(
        "formulario_pedido_saida.html",
        pedido=pedido
    )


@app.route("/pedido-saida/atualizar/<int:id>", methods=["POST"])
def atualizar_pedido_saida(id):

    dados = get_pedido_saida()
    pedido = PedidoSaida(**dados)

    try:
        pedido.update(id)
        flash("Atualizado com sucesso!", "sucesso")
        return redirect(url_for("listar_pedido_saida"))

    except Exception as e:
        flash(f"Erro: {e}", "erro")
        dados["id_pedido_saida_cabecalho"] = id
        return render_template("formulario_pedido_saida.html", pedido=dados)


@app.route("/pedido-saida/excluir/<int:id>")
def excluir_pedido_saida(id):

    conn = Database.connect()
    cursor = conn.cursor()

    # remove movimentação
    cursor.execute("""
        DELETE FROM movimentacao
        WHERE observacao = %s
    """, (f"Pedido saída #{id}",))

    # remove pedido
    cursor.execute(
        "DELETE FROM pedido_saida_cabecalho WHERE id_pedido_saida_cabecalho = %s",
        (id,)
    )

    conn.commit()
    cursor.close()
    conn.close()

    flash("Excluído com sucesso!", "sucesso")
    return redirect(url_for("listar_pedido_saida"))








#--------------- ITEM ENTRADA --------------------- #



@app.route("/item-entrada")
def listar_item_entrada():
    return render_template(
        "item_entrada.html",
        itens=ItemPedidoEntrada.find_all()
    )


@app.route("/item-entrada/novo")
def novo_item_entrada():
    estoques = Estoque.find_all()
    produtos = Produto.find_all()

    return render_template(
        "formulario_item_entrada.html",
        item=None,
        estoques=estoques,
        produtos=produtos
    )


@app.route("/item-entrada/salvar", methods=["POST"])
def salvar_item_entrada():

    produto_id = request.form.get("produto_id_produto")
    qtd = request.form.get("qtd")
    preco = request.form.get("preco_unitario")
    estoque_id = request.form.get("estoque_id_estoque")

    if not produto_id or not qtd or not preco or not estoque_id:
        flash("Preencha todos os campos!", "erro")
        return redirect(url_for("novo_item_entrada"))

    try:
        item = ItemPedidoEntrada(produto_id, qtd, preco, estoque_id)
        item.insert()

        flash("Item de entrada cadastrado com sucesso!", "sucesso")
        return redirect(url_for("listar_item_entrada"))

    except Exception as e:
        flash(f"Erro ao salvar: {e}", "erro")
        return redirect(url_for("novo_item_entrada"))


@app.route("/item-entrada/editar/<int:id>")
def editar_item_entrada(id):

    conexao = Database.connect()
    cursor = conexao.cursor(dictionary=True)

    cursor.execute("""
        SELECT * FROM Item_pedido_entrada
        WHERE idItem_pedido_entrada = %s
    """, (id,))

    item = cursor.fetchone()

    cursor.close()
    conexao.close()

    estoques = Estoque.find_all()
    produtos = Produto.find_all()

    return render_template(
        "formulario_item_entrada.html",
        item=item,
        estoques=estoques,
        produtos=produtos
    )


@app.route("/item-entrada/atualizar/<int:id>", methods=["POST"])
def atualizar_item_entrada(id):

    produto_id = request.form.get("produto_id_produto")
    qtd = request.form.get("qtd")
    preco = request.form.get("preco_unitario")
    estoque_id = request.form.get("estoque_id_estoque")

    try:
        conexao = Database.connect()
        cursor = conexao.cursor()

        cursor.execute("""
            UPDATE Item_pedido_entrada
            SET produto_id_produto = %s,
                qtd = %s,
                preco_unitario = %s,
                estoque_id_estoque = %s
            WHERE idItem_pedido_entrada = %s
        """, (produto_id, qtd, preco, estoque_id, id))

        conexao.commit()
        cursor.close()
        conexao.close()

        flash("Item atualizado com sucesso!", "sucesso")

    except Exception as e:
        flash(f"Erro ao atualizar: {e}", "erro")

    return redirect(url_for("listar_item_entrada"))


@app.route("/item-entrada/excluir/<int:id>")
def excluir_item_entrada(id):

    try:
        ItemPedidoEntrada.delete(id)
        flash("Item excluído com sucesso!", "sucesso")

    except Exception as e:
        flash(f"Erro ao excluir: {e}", "erro")

    return redirect(url_for("listar_item_entrada"))

#-------------- ITEM SAIDA -----------------#





@app.route("/item-saida")
def listar_item_saida():
    return render_template(
        "item_saida.html",
        itens=ItemPedidoSaida.find_all()
    )


@app.route("/item-saida/novo")
def novo_item_saida():
    produtos = Produto.find_all()
    estoques = Estoque.find_all()

    return render_template(
        "formulario_item_saida.html",
        item=None,
        produtos=produtos,
        estoques=estoques
    )


@app.route("/item-saida/salvar", methods=["POST"])
def salvar_item_saida():

    produto_id = request.form.get("produto_id_produto")
    qtd = request.form.get("qtd")
    preco = request.form.get("preco_unitario")
    data = request.form.get("data")
    status = request.form.get("status")
    estoque_id = request.form.get("estoque_id_estoque")

    try:
        item = ItemPedidoSaida(produto_id, qtd, preco, data, status, estoque_id)
        item.insert()

        flash("Item de saída cadastrado com sucesso!", "sucesso")
        return redirect(url_for("listar_item_saida"))

    except Exception as e:
        flash(f"Erro: {e}", "erro")
        return redirect(url_for("novo_item_saida"))


@app.route("/item-saida/editar/<int:id>")
def editar_item_saida(id):

    conexao = Database.connect()
    cursor = conexao.cursor(dictionary=True)

    cursor.execute("""
        SELECT * FROM item_pedido_saida
        WHERE id_item_pedido_saida = %s
    """, (id,))

    item = cursor.fetchone()

    cursor.close()
    conexao.close()

    produtos = Produto.find_all()
    estoques = Estoque.find_all()

    return render_template(
        "formulario_item_saida.html",
        item=item,
        produtos=produtos,
        estoques=estoques
    )


@app.route("/item-saida/atualizar/<int:id>", methods=["POST"])
def atualizar_item_saida(id):

    produto_id = request.form.get("produto_id_produto")
    qtd = request.form.get("qtd")
    preco = request.form.get("preco_unitario")
    data = request.form.get("data")
    status = request.form.get("status")
    estoque_id = request.form.get("estoque_id_estoque")

    try:
        conexao = Database.connect()
        cursor = conexao.cursor()

        cursor.execute("""
            UPDATE item_pedido_saida
            SET produto_id_produto = %s,
                qtd = %s,
                preco_unitario = %s,
                data = %s,
                status = %s,
                estoque_id_estoque = %s
            WHERE id_item_pedido_saida = %s
        """, (produto_id, qtd, preco, data, status, estoque_id, id))

        conexao.commit()
        cursor.close()
        conexao.close()

        flash("Item atualizado com sucesso!", "sucesso")

    except Exception as e:
        flash(f"Erro ao atualizar: {e}", "erro")

    return redirect(url_for("listar_item_saida"))


@app.route("/item-saida/excluir/<int:id>")
def excluir_item_saida(id):

    try:
        ItemPedidoSaida.delete(id)
        flash("Item excluído com sucesso!", "sucesso")

    except Exception as e:
        flash(f"Erro: {e}", "erro")

    return redirect(url_for("listar_item_saida"))




# =========================
# DADOS SENSORES
# =========================

@app.route("/dados_sensores")
def listar_dados_sensor():

    return render_template(
        "dados_sensores.html",
        dados=DadosSensores.find_all()   
    )


@app.route("/dados_sensores/novo")
def novo_dados_sensor():

    return render_template(
        "formulario_dados_sensores.html",
        dado=None,                       
        sensores_lista=Sensor.find_all()
    )


@app.route("/dados_sensores/salvar", methods=["POST"])
def salvar_dados_sensor():

    dados = get_dados_sensores()
    dado = DadosSensores(**dados)     

    dado.insert()

    flash("Dados do sensor salvos com sucesso.", "sucesso")
    return redirect(url_for("listar_dados_sensor"))


@app.route("/dados_sensores/editar/<int:id>")
def editar_dados_sensor(id):

    dado = DadosSensores.find_by_id(id)

    if not dado:
        flash("Registro não encontrado.", "erro")
        return redirect(url_for("listar_dados_sensor"))

    return render_template(
        "formulario_dados_sensores.html",
        dado=dado,                     
        sensores_lista=Sensor.find_all()
    )


@app.route("/dados_sensores/atualizar/<int:id>", methods=["POST"])
def atualizar_dados_sensor(id):

    dados = get_dados_sensores()
    dado = DadosSensores(**dados)     
    dado.update(id)

    flash("Atualizado com sucesso.", "sucesso")
    return redirect(url_for("listar_dados_sensor"))


@app.route("/dados_sensores/excluir/<int:id>", methods=["POST"])
def excluir_dados_sensor(id):

    DadosSensores.delete(id)

    flash("Excluído com sucesso.", "sucesso")
    return redirect(url_for("listar_dados_sensor"))

if __name__ == "__main__":
    app.run(debug=True)
