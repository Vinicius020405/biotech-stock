from core.crud_base import CrudBase
from core.database import Database
from core.validator import Validator


class cliente(CrudBase):
    table = "cliente"
    fields = [
        "nome",
        "cpf",
        "senha",
        
    ]

    def __init__(self, localizacao_sensor):
        self.localizacao_sensor = localizacao_sensor