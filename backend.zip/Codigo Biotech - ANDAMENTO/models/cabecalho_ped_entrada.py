from core.database import Database
from core.crud_base import CrudBase
from core.validator import Validator

class PedidoEntrada:

    table = "cabecalho_ped_entrada"

    def __init__(self, criacao_pedido, cliente, tipo, qntd, usuario_id_usuario, data_entrada):
        self.criacao_pedido = criacao_pedido
        self.cliente = cliente
        self.tipo = tipo
        self.qntd = qntd
        self.usuario_id_usuario = usuario_id_usuario
        self.data_entrada = data_entrada

    def insert(self):
        conexao = Database.connect()
        cursor = conexao.cursor()

        sql = """
        INSERT INTO cabecalho_ped_entrada
        (criacao_pedido, cliente, tipo, qntd, usuario_id_usuario, data_entrada)
        VALUES (%s, %s, %s, %s, %s, %s)
        """

        cursor.execute(sql, (
            self.criacao_pedido,
            self.cliente,
            self.tipo,
            self.qntd,
            self.usuario_id_usuario,
            self.data_entrada
        ))

        conexao.commit()
        cursor.close()
        conexao.close()

    @classmethod
    def find_all(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        cursor.execute("SELECT * FROM cabecalho_ped_entrada")
        dados = cursor.fetchall()

        cursor.close()
        conexao.close()

        return dados