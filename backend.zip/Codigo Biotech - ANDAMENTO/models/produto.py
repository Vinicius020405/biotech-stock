from core.database import Database


class Produto:

    def __init__(self, nome_produto, categoria, preco_custo, preco_venda,
                 tipo, data_validade, estoque_id_estoque, descricao,
                 unidade_medida, idproduto=None):

        self.idproduto = idproduto
        self.nome_produto = nome_produto
        self.categoria = categoria
        self.preco_custo = preco_custo
        self.preco_venda = preco_venda
        self.tipo = tipo
        self.data_validade = data_validade
        self.estoque_id_estoque = estoque_id_estoque
        self.descricao = descricao
        self.unidade_medida = unidade_medida

    def validate(self):
        erros = []

        if not self.nome_produto:
            erros.append("Nome obrigatório")
        if not self.categoria:
            erros.append("Categoria obrigatória")
        if self.preco_custo is None:
            erros.append("Preço custo obrigatório")
        if self.preco_venda is None:
            erros.append("Preço venda obrigatório")
        if not self.tipo:
            erros.append("Tipo obrigatório")
        if not self.data_validade:
            erros.append("Data validade obrigatória")
        if not self.estoque_id_estoque:
            erros.append("Estoque obrigatório")

        return erros

    def insert(self):
        conn = Database.connect()
        cur = conn.cursor()

        cur.execute("""
            INSERT INTO produto (
                nome_produto, categoria, preco_custo, preco_venda,
                tipo, data_validade, estoque_id_estoque,
                `Descrição`, Unidade_de_Medida
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            self.nome_produto,
            self.categoria,
            self.preco_custo,
            self.preco_venda,
            self.tipo,
            self.data_validade,
            self.estoque_id_estoque,
            self.descricao,
            self.unidade_medida
        ))

        conn.commit()
        cur.close()
        conn.close()

    def update(self, id):
        conn = Database.connect()
        cur = conn.cursor()

        cur.execute("""
            UPDATE produto SET
                nome_produto=%s,
                categoria=%s,
                preco_custo=%s,
                preco_venda=%s,
                tipo=%s,
                data_validade=%s,
                estoque_id_estoque=%s,
                `Descrição`=%s,
                Unidade_de_Medida=%s
            WHERE idproduto=%s
        """, (
            self.nome_produto,
            self.categoria,
            self.preco_custo,
            self.preco_venda,
            self.tipo,
            self.data_validade,
            self.estoque_id_estoque,
            self.descricao,
            self.unidade_medida,
            id
        ))

        conn.commit()
        cur.close()
        conn.close()

    @classmethod
    def delete(cls, id):
        conn = Database.connect()
        cur = conn.cursor()

        cur.execute("DELETE FROM produto WHERE idproduto=%s", (id,))

        conn.commit()
        cur.close()
        conn.close()

    @classmethod
    def find_all(cls):
        conn = Database.connect()
        cur = conn.cursor(dictionary=True)

        cur.execute("SELECT * FROM produto")
        dados = cur.fetchall()

        cur.close()
        conn.close()

        return dados

    @classmethod
    def find_by_id(cls, id):
        conn = Database.connect()
        cur = conn.cursor(dictionary=True)

        cur.execute("SELECT * FROM produto WHERE idproduto=%s", (id,))
        dado = cur.fetchone()

        cur.close()
        conn.close()

        return dado