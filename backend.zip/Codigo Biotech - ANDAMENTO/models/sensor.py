from core.crud_base import CrudBase
from core.database import Database
from core.validator import Validator

class Sensor(CrudBase):
    table = "sensores"
    fields = [
        "tipo",
        "descricao",
        "localizacao_sensor"
    ]

    def __init__(self, tipo, descricao, localizacao_sensor):
        self.tipo = tipo
        self.descricao = descricao
        self.localizacao_sensor = localizacao_sensor

    def validate(self):
        erros = [
            Validator.required(self.tipo, "tipo"),
            Validator.required(self.localizacao_sensor, "localização do sensor")
        ]
        return [erro for erro in erros if erro]

    @classmethod
    def has_related_records(cls, id):
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            queries = [
                
                "SELECT COUNT(*) FROM dados_sensores WHERE sensor_id = %s"
            ]
            total = 0
            for sql in queries:
                cursor.execute(sql, (id,))
                total += cursor.fetchone()[0]
            return total > 0
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def safe_delete(cls, id):
        sensor = cls.find_by_id(id)
        if not sensor:
            raise ValueError("Sensor não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o sensor pois possui registros vinculados.")
        cls.delete(id)