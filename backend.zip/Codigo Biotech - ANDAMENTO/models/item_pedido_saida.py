from core.database import Database
from core.crud_base import CrudBase
from core.validator import Validator

class ItemPedidoSaida:

    table = "item_pedido_saida"

    def __init__(self, data, status, estoque_id_estoque):
        self.data = data
        self.status = status
        self.estoque_id_estoque = estoque_id_estoque

    def insert(self):
        conexao = Database.connect()
        cursor = conexao.cursor()

        sql = """
        INSERT INTO item_pedido_saida (data, status, estoque_id_estoque)
        VALUES (%s, %s, %s)
        """

        cursor.execute(sql, (
            self.data,
            self.status,
            self.estoque_id_estoque
        ))

        conexao.commit()
        cursor.close()
        conexao.close()

    @classmethod
    def find_all(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        cursor.execute("SELECT * FROM item_pedido_saida")
        dados = cursor.fetchall()

        cursor.close()
        conexao.close()

        return dados

    @classmethod
    def find_by_id(cls, id):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        cursor.execute("""
            SELECT * FROM item_pedido_saida
            WHERE id_item_pedido_saida = %s
        """, (id,))

        dados = cursor.fetchone()

        cursor.close()
        conexao.close()

        return dados

    @classmethod
    def delete(cls, id):
        conexao = Database.connect()
        cursor = conexao.cursor()

        cursor.execute("""
            DELETE FROM item_pedido_saida
            WHERE id_item_pedido_saida = %s
        """, (id,))

        conexao.commit()
        cursor.close()
        conexao.close()