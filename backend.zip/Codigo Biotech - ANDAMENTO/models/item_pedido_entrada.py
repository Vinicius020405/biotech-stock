from core.database import Database
from core.crud_base import CrudBase
from core.validator import Validator


class ItemPedidoEntrada:

    table = "Item_pedido_entrada"

    def __init__(self, qtd, estoque_id_estoque):
        self.qtd = qtd
        self.estoque_id_estoque = estoque_id_estoque

    def insert(self):
        conexao = Database.connect()
        cursor = conexao.cursor()

        sql = """
        INSERT INTO Item_pedido_entrada (qtd, estoque_id_estoque)
        VALUES (%s, %s)
        """

        cursor.execute(sql, (
            self.qtd,
            self.estoque_id_estoque
        ))

        conexao.commit()
        cursor.close()
        conexao.close()

    @classmethod
    def find_all(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        cursor.execute("""
            SELECT * FROM Item_pedido_entrada
        """)

        dados = cursor.fetchall()

        cursor.close()
        conexao.close()

        return dados

    @classmethod
    def find_by_id(cls, id):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        cursor.execute("""
            SELECT * FROM Item_pedido_entrada
            WHERE idItem_pedido_entrada = %s
        """, (id,))

        dados = cursor.fetchone()

        cursor.close()
        conexao.close()

        return dados

    @classmethod
    def delete(cls, id):
        conexao = Database.connect()
        cursor = conexao.cursor()

        cursor.execute("""
            DELETE FROM Item_pedido_entrada
            WHERE idItem_pedido_entrada = %s
        """, (id,))

        conexao.commit()
        cursor.close()
        conexao.close()