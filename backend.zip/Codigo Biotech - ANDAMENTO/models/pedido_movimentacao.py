from datetime import datetime
from core.database import Database
from core.validator import Validator
from models.produto import Produto
from models.movimentacao import Movimentacao


class PedidoMovimentacao:

    table = "pedido_movimentacao"

    def __init__(self, produto_id, tipo, quantidade, status="PENDENTE",
                 observacao="", data_pedido=None, data_processamento=None):

        self.produto_id = produto_id
        self.tipo = tipo
        self.quantidade = quantidade
        self.status = status
        self.observacao = observacao
        self.data_pedido = data_pedido or datetime.now()
        self.data_processamento = data_processamento

    def validate(self):
        erros = []

        if Validator.positive(self.produto_id, "produto"):
            erros.append(Validator.positive(self.produto_id, "produto"))

        if Validator.positive(self.quantidade, "quantidade"):
            erros.append(Validator.positive(self.quantidade, "quantidade"))

        if self.tipo not in ["ENTRADA", "SAIDA"]:
            erros.append("Tipo deve ser ENTRADA ou SAIDA")

        return erros

    @classmethod
    def find_all_with_product(cls):
        conn = Database.connect()
        cur = conn.cursor(dictionary=True)

        cur.execute("""
            SELECT pm.*, p.nome_produto AS produto
            FROM pedido_movimentacao pm
            JOIN produto p ON pm.produto_id = p.idproduto
            ORDER BY pm.data_pedido DESC
        """)

        dados = cur.fetchall()

        cur.close()
        conn.close()

        return dados

    @classmethod
    def processar(cls, id):
        conn = Database.connect()
        cur = conn.cursor(dictionary=True)

        try:
            conn.start_transaction()

            cur.execute("SELECT * FROM pedido_movimentacao WHERE id=%s FOR UPDATE", (id,))
            pedido = cur.fetchone()

            if not pedido:
                return "Pedido não encontrado"
            if pedido["status"] != "PENDENTE":
                return "Pedido já processado"

            cur.execute("SELECT * FROM produto WHERE id=%s FOR UPDATE", (pedido["produto_id"],))
            produto = cur.fetchone()

            if not produto:
                return "Produto não encontrado"

            if pedido["tipo"] == "ENTRADA":
                nova_qtd = produto["quantidade"] + pedido["quantidade"]

            elif pedido["tipo"] == "SAIDA":
                if pedido["quantidade"] > produto["quantidade"]:
                    return "Estoque insuficiente"
                nova_qtd = produto["quantidade"] - pedido["quantidade"]

            else:
                return "Tipo inválido"

            Produto.update_quantity(produto["id"], nova_qtd, connection=conn)

            mov = Movimentacao(produto["id"], pedido["tipo"], pedido["quantidade"])

            cur.execute("""
                INSERT INTO movimentacao
                (produto_id, tipo_movimentacao, quantidade, data_movimentacao)
                VALUES (%s, %s, %s, %s)
            """, (
                mov.produto_id,
                mov.tipo_movimentacao,
                mov.quantidade,
                mov.data_movimentacao
            ))

            cur.execute("""
                UPDATE pedido_movimentacao
                SET status=%s, data_processamento=%s
                WHERE id=%s
            """, ("CONCLUIDO", datetime.now(), id))

            conn.commit()
            return "Pedido processado"

        except:
            conn.rollback()
            return "Erro ao processar pedido"

        finally:
            cur.close()
            conn.close()

    @classmethod
    def cancelar(cls, id):
        conn = Database.connect()
        cur = conn.cursor(dictionary=True)

        try:
            cur.execute("SELECT * FROM pedido_movimentacao WHERE id=%s", (id,))
            pedido = cur.fetchone()

            if not pedido:
                return "Pedido não encontrado"
            if pedido["status"] != "PENDENTE":
                return "Não pode cancelar"

            cur.execute("""
                UPDATE pedido_movimentacao
                SET status=%s, data_processamento=%s
                WHERE id=%s
            """, ("CANCELADO", datetime.now(), id))

            conn.commit()
            return "Pedido cancelado"

        except:
            conn.rollback()
            return "Erro ao cancelar"

        finally:
            cur.close()
            conn.close()