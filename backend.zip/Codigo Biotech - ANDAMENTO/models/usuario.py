from core.crud_base import CrudBase
from core.database import Database
from core.validator import Validator

class Usuario(CrudBase):
    table = "usuario"
    fields = [
        "nome",
        "cpf",
        "senha"
    ]

    def __init__(self, nome, cpf, senha):
        self.nome = nome
        self.cpf = cpf
        self.senha = senha

    def validate(self):
        erros = [
            Validator.required(self.nome, "nome"),
            Validator.required(self.cpf, "cpf"),
            Validator.required(self.senha, "senha")
        ]
        return [erro for erro in erros if erro]

    @classmethod
    def has_related_records(cls, id):
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            queries = [
                
                "SELECT COUNT(*) FROM movimentacao WHERE usuario_id = %s"
            ]
            total = 0
            for sql in queries:
                cursor.execute(sql, (id,))
                total += cursor.fetchone()[0]
            return total > 0
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def safe_delete(cls, id):
        usuario = cls.find_by_id(id)
        if not usuario:
            raise ValueError("Usuário não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o usuário pois possui registros vinculados.")
        cls.delete(id)