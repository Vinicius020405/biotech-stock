from core.database import Database
from core.crud_base import CrudBase
from core.validator import Validator


class Estoque:

    def __init__(
        self,
        dados_sensores_id_dados_sensores,
        quantidade_atual,
        quantidade_minima,
        quantidade_maxima,
        id_estoque=None
    ):
        self.id_estoque = id_estoque
        self.dados_sensores_id_dados_sensores = dados_sensores_id_dados_sensores
        self.quantidade_atual = quantidade_atual
        self.quantidade_minima = quantidade_minima
        self.quantidade_maxima = quantidade_maxima

    
    def validate(self):
        erros = []

        if not self.dados_sensores_id_dados_sensores:
            erros.append("Selecione um sensor válido")

        if self.quantidade_atual is None:
            erros.append("Quantidade atual obrigatória")

        if self.quantidade_minima is None:
            erros.append("Quantidade mínima obrigatória")

        if self.quantidade_maxima is None:
            erros.append("Quantidade máxima obrigatória")

        return erros

   
    def insert(self):
        conexao = Database.connect()
        cursor = conexao.cursor()

        sql = """
        INSERT INTO estoque (
            dados_sensores_id_dados_sensores,
            quantidade_atual,
            quantidade_minima,
            quantidade_maxima
        )
        VALUES (%s, %s, %s, %s)
        """

        cursor.execute(sql, (
            self.dados_sensores_id_dados_sensores,
            self.quantidade_atual,
            self.quantidade_minima,
            self.quantidade_maxima
        ))

        conexao.commit()
        cursor.close()
        conexao.close()

  
    def update(self, id):
        conexao = Database.connect()
        cursor = conexao.cursor()

        sql = """
        UPDATE estoque SET
            dados_sensores_id_dados_sensores=%s,
            quantidade_atual=%s,
            quantidade_minima=%s,
            quantidade_maxima=%s
        WHERE id_estoque=%s
        """

        cursor.execute(sql, (
            self.dados_sensores_id_dados_sensores,
            self.quantidade_atual,
            self.quantidade_minima,
            self.quantidade_maxima,
            id
        ))

        conexao.commit()
        cursor.close()
        conexao.close()

    
    @classmethod
    def delete(cls, id):
        conexao = Database.connect()
        cursor = conexao.cursor()

        cursor.execute("DELETE FROM estoque WHERE id_estoque=%s", (id,))

        conexao.commit()
        cursor.close()
        conexao.close()

    
    @classmethod
    def find_all(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        cursor.execute("SELECT * FROM estoque")
        dados = cursor.fetchall()

        cursor.close()
        conexao.close()

        return dados

    
    @classmethod
    def find_by_id(cls, id):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        cursor.execute("SELECT * FROM estoque WHERE id_estoque=%s", (id,))
        dado = cursor.fetchone()

        cursor.close()
        conexao.close()

        return dado