from datetime import datetime
from core.crud_base import CrudBase
from core.database import Database

class Movimentacao(CrudBase):
    table = "movimentacao"
    fields = [
        "tipo",
        "quantidade",
        "observacao",
        "data_movimentacao"
    ]

    def __init__(self, tipo, quantidade, observacao, data_movimentacao=None):
        self.tipo = tipo
        self.quantidade = quantidade
        self.observacao = observacao
        self.data_movimentacao = data_movimentacao or datetime.now()

    @classmethod
    def find_all(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = """
            SELECT 
                id_movimentacao,
                tipo,
                quantidade,
                observacao,
                data_movimentacao
            FROM movimentacao
            ORDER BY id_movimentacao DESC
            """
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()