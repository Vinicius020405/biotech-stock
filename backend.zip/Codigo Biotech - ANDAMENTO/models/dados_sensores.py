from core.crud_base import CrudBase
from core.database import Database
from core.validator import Validator


class DadosSensores(CrudBase):

    table = "dados_sensores"

    fields = [
        "tipo",
        "descricao",
        "sensores_id_sensores"
    ]

    def __init__(self, tipo, descricao, sensores_id_sensores):
        self.tipo = tipo
        self.descricao = descricao
        self.sensores_id_sensores = sensores_id_sensores

    def validate(self):
        erros = [
            Validator.required(self.tipo, "tipo"),
            Validator.required(self.descricao, "descricao"),
            Validator.required(self.sensores_id_sensores, "sensores")
        ]
        return [erro for erro in erros if erro]

    @classmethod
    def has_related_records(cls, id):
        conexao = Database.connect()
        cursor = conexao.cursor()

        try:
            queries = [
                "SELECT COUNT(*) FROM estoque WHERE dados_sensores_id_dados_sensores = %s",
                "SELECT COUNT(*) FROM item_pedido_entrada WHERE dados_sensores_id = %s",
                "SELECT COUNT(*) FROM item_pedido_saida WHERE dados_sensores_id = %s"
            ]

            total = 0

            for sql in queries:
                cursor.execute(sql, (id,))
                total += cursor.fetchone()[0]

            return total > 0

        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def safe_delete(cls, id):
        sensor = cls.find_by_id(id)

        if not sensor:
            raise ValueError("Sensor não encontrado.")

        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir, existem registros vinculados.")

        cls.delete(id)