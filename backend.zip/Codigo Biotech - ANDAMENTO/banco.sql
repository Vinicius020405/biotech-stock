CREATE TABLE IF NOT EXISTS sensores (
  id_sensores INT NOT NULL,
  localizacao_sensor VARCHAR(45) NOT NULL,
  PRIMARY KEY (id_sensores)
);

CREATE TABLE IF NOT EXISTS dados_sensores (
  id_dados_sensores INT NOT NULL,
  tipo VARCHAR(100) NOT NULL,
  descricao VARCHAR(100) NOT NULL,
  sensores_id_sensores INT NOT NULL,
  PRIMARY KEY (id_dados_sensores),
  FOREIGN KEY (sensores_id_sensores)
    REFERENCES sensores (id_sensores)
);

CREATE TABLE IF NOT EXISTS estoque (
  id_estoque INT NOT NULL,
  dados_sensores_id_dados_sensores INT NOT NULL,
  quantidade_atual INT NOT NULL,
  quantidade_minima INT NOT NULL,
  quantidade_maxima INT NOT NULL,
  PRIMARY KEY (id_estoque),
  FOREIGN KEY (dados_sensores_id_dados_sensores)
    REFERENCES dados_sensores (id_dados_sensores)
);

CREATE TABLE IF NOT EXISTS Item_pedido_entrada (
  idItem_pedido_entrada INT NOT NULL,
  qtd INT NOT NULL,
  estoque_id_estoque INT NOT NULL,
  PRIMARY KEY (idItem_pedido_entrada),
  FOREIGN KEY (estoque_id_estoque)
    REFERENCES estoque (id_estoque)
);

CREATE TABLE IF NOT EXISTS usuario (
  id_usuario INT NOT NULL,
  nome VARCHAR(50) NOT NULL,
  cpf VARCHAR(11) NOT NULL,
  senha VARCHAR(10) NOT NULL,
  email VARCHAR(45) NOT NULL,
  cargo VARCHAR(45) NOT NULL,
  admin TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id_usuario)
);

CREATE TABLE IF NOT EXISTS cabecalho_ped_entrada (
  idcabecalho_ped_entrada INT NOT NULL,
  Item_pedido_entrada_idItem_pedido_entrada INT NOT NULL,
  criacao_pedido DATE NOT NULL,
  cliente VARCHAR(45) NOT NULL,
  tipo VARCHAR(50) NOT NULL,
  qntd INT NOT NULL,
  usuario_id_usuario INT NOT NULL,
  data_entrada DATE NOT NULL,
  PRIMARY KEY (idcabecalho_ped_entrada),
  FOREIGN KEY (Item_pedido_entrada_idItem_pedido_entrada)
    REFERENCES Item_pedido_entrada (idItem_pedido_entrada),
  FOREIGN KEY (usuario_id_usuario)
    REFERENCES usuario (id_usuario)
);

CREATE TABLE IF NOT EXISTS fornecedor (
  id_fornecedor INT NOT NULL,
  nome VARCHAR(100) NOT NULL,
  cnpj VARCHAR(14) NOT NULL,
  email VARCHAR(100) NOT NULL,
  senha VARCHAR(8) NOT NULL,
  cabecalho_ped_entrada_idcabecalho_ped_entrada INT NOT NULL,
  PRIMARY KEY (id_fornecedor),
  FOREIGN KEY (cabecalho_ped_entrada_idcabecalho_ped_entrada)
    REFERENCES cabecalho_ped_entrada (idcabecalho_ped_entrada)
);

CREATE TABLE IF NOT EXISTS produto (
  idproduto INT NOT NULL,
  nome_produto VARCHAR(25) NOT NULL,
  categoria VARCHAR(10) NOT NULL,
  preco_custo FLOAT NOT NULL,
  preco_venda FLOAT NOT NULL,
  tipo VARCHAR(60) NOT NULL,
  data_validade DATE NOT NULL,
  estoque_id_estoque INT NOT NULL,
  Descricao VARCHAR(100) NOT NULL,
  Unidade_de_Medida INT NOT NULL,
  PRIMARY KEY (idproduto),
  FOREIGN KEY (estoque_id_estoque)
    REFERENCES estoque (id_estoque)
);

CREATE TABLE IF NOT EXISTS caminhao (
  id_caminhao INT NOT NULL,
  placa VARCHAR(8) NOT NULL,
  modelo VARCHAR(45) NOT NULL,
  cor VARCHAR(20) NOT NULL,
  marca VARCHAR(45) NOT NULL,
  chassi VARCHAR(17) NOT NULL,
  PRIMARY KEY (id_caminhao)
);

CREATE TABLE IF NOT EXISTS item_pedido_saida (
  id_item_pedido_saida INT NOT NULL,
  data DATE NOT NULL,
  status VARCHAR(100) NOT NULL,
  estoque_id_estoque INT NOT NULL,
  PRIMARY KEY (id_item_pedido_saida),
  FOREIGN KEY (estoque_id_estoque)
    REFERENCES estoque (id_estoque)
);

CREATE TABLE cliente (
  id_cliente INT AUTO_INCREMENT PRIMARY KEY,
  produto_idproduto INT NOT NULL,
  cabecalho_ped_entrada_idcabecalho_ped_entrada INT NOT NULL,
  nome VARCHAR(100) NOT NULL,
  cpf VARCHAR(11) NOT NULL,
  senha VARCHAR(50) NOT NULL,
  FOREIGN KEY (produto_idproduto)
    REFERENCES produto (idproduto),
  FOREIGN KEY (cabecalho_ped_entrada_idcabecalho_ped_entrada)
    REFERENCES cabecalho_ped_entrada (idcabecalho_ped_entrada)
);

CREATE TABLE IF NOT EXISTS pedido_saida_cabecalho (
  id_pedido_saida_cabecalho INT NOT NULL,
  data DATE NOT NULL,
  status VARCHAR(100) NOT NULL,
  caminhao_id_caminhao INT NOT NULL,
  item_pedido_saida_id_item_pedido_saida INT NOT NULL,
  usuario_id_usuario INT NOT NULL,
  cliente_id_cliente INT NOT NULL,
  PRIMARY KEY (id_pedido_saida_cabecalho),
  FOREIGN KEY (caminhao_id_caminhao)
    REFERENCES caminhao (id_caminhao),
  FOREIGN KEY (item_pedido_saida_id_item_pedido_saida)
    REFERENCES item_pedido_saida (id_item_pedido_saida),
  FOREIGN KEY (usuario_id_usuario)
    REFERENCES usuario (id_usuario),
  FOREIGN KEY (cliente_id_cliente)
    REFERENCES cliente (id_cliente)
);

CREATE TABLE IF NOT EXISTS movimentacao (
  id_movimentacao INT NOT NULL,
  tipo VARCHAR(45) NOT NULL,
  quantidade INT NOT NULL,
  observacao VARCHAR(45) NOT NULL,
  data_movimentacao DATE NOT NULL,
  Item_pedido_entrada_idItem_pedido_entrada INT NOT NULL,
  item_pedido_saida_id_item_pedido_saida INT NOT NULL,
  PRIMARY KEY (id_movimentacao),
  FOREIGN KEY (Item_pedido_entrada_idItem_pedido_entrada)
    REFERENCES Item_pedido_entrada (idItem_pedido_entrada),
  FOREIGN KEY (item_pedido_saida_id_item_pedido_saida)
    REFERENCES item_pedido_saida (id_item_pedido_saida)
);