import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Alert } from 'react-native';
import api from '../src/services/api';

export default function ExitScreen({ navigation }) {
  const [docNumber, setDocNumber] = useState('');
  const [applicant, setApplicant] = useState('');
  const [quantity, setQuantity] = useState('');
  const [currentStock, setCurrentStock] = useState(0);

  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);

  useEffect(() => {
    async function init() {
      try {
        const resProd = await api.get('/produto');
        setProducts(resProd.data);
        if (resProd.data.length > 0) {
          const prod = resProd.data[0];
          setSelectedProduct(prod);
          
          const resStock = await api.get('/estoque');
          const stock = resStock.data.find(s => s.id_produto === prod.id_produto);
          setCurrentStock(stock ? Number(stock.quantidade_atual) : 0);
        }
      } catch (err) {
        console.log(err);
      }
    }
    init();
  }, []);

  const handleConfirmExit = async () => {
    const qtyNum = Number(quantity);

    if (!docNumber || !applicant) return Alert.alert('Erro', 'Preencha todos os campos obrigatórios.');
    if (!quantity || isNaN(qtyNum) || qtyNum <= 0) return Alert.alert('Erro', 'Informe uma quantidade válida.');
    
    // Validação com IF no Mobile
    if (qtyNum > currentStock) {
      return Alert.alert('Saldo Insuficiente', `Saldo atual em estoque: ${currentStock}`);
    }

    try {
      // 1. Criar Pedido de Saída
      const resPedido = await api.post('/pedido-saida', {
        numero_documento: docNumber,
        solicitante: applicant,
        data_saida: new Date().toISOString().slice(0, 10),
        id_usuario: 15,
        id_caminhao: 1,
        status: 'finalizado'
      });

      const idPedido = resPedido.data.id_pedido_saida || resPedido.data.insertId;

      // 2. Criar Item do Pedido
      await api.post('/item-pedido-saida', {
        id_pedido_saida: idPedido,
        id_produto: selectedProduct.id_produto,
        id_localizacao: 1,
        quantidade: qtyNum
      });

      Alert.alert('Sucesso', 'Saída registrada com sucesso!', [
        { text: 'OK', onPress: () => navigation.navigate('Home') }
      ]);
    } catch (err) {
      Alert.alert('Erro', 'Falha ao registrar saída.');
    }
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Lançar Saída</Text>
      <Text style={styles.stockBadge}>Saldo Atual: {currentStock}</Text>

      <Text style={styles.label}>Número Documento / Pedido *</Text>
      <TextInput style={styles.input} placeholder="Ex: SAI-2024-088" placeholderTextColor="#94A3B8" value={docNumber} onChangeText={setDocNumber} />

      <Text style={styles.label}>Solicitante / Destino *</Text>
      <TextInput style={styles.input} placeholder="Ex: Filial Sul" placeholderTextColor="#94A3B8" value={applicant} onChangeText={setApplicant} />

      <Text style={styles.label}>Quantidade a Retirar *</Text>
      <TextInput style={styles.input} placeholder="Ex: 20" keyboardType="numeric" placeholderTextColor="#94A3B8" value={quantity} onChangeText={setQuantity} />

      <TouchableOpacity style={styles.button} onPress={handleConfirmExit}>
        <Text style={styles.buttonText}>Confirmar Saída</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#020617', paddingHorizontal: 20, paddingTop: 50 },
  title: { color: '#fff', fontSize: 26, fontWeight: 'bold' },
  stockBadge: { color: '#38BDF8', fontSize: 14, fontWeight: 'bold', marginTop: 4, marginBottom: 20 },
  label: { color: '#94A3B8', fontSize: 14, marginTop: 12, marginBottom: 6 },
  input: { backgroundColor: '#1E293B', height: 50, borderRadius: 12, paddingHorizontal: 15, color: '#fff' },
  button: { backgroundColor: '#DC2626', height: 52, borderRadius: 14, marginTop: 30, justifyContent: 'center', alignItems: 'center' },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' }
});