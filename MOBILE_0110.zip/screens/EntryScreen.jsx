import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert
} from 'react-native';

import api from '../src/services/api';
import QRCodeScannerModal from '../src/components/QRCodeScannerModal';

export default function EntryScreen({ navigation }) {
  const [docNumber, setDocNumber] = useState('');
  const [quantity, setQuantity] = useState('');
  const [unitValue, setUnitValue] = useState('');
  const [observation, setObservation] = useState('');

  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);

  const [isScannerOpen, setIsScannerOpen] = useState(false);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const response = await api.get('/produtos');

      setProducts(response.data);

      if (response.data.length > 0) {
        setSelectedProduct(response.data[0]);
      }
    } catch (error) {
      console.log('Erro ao carregar produtos:', error);
    }
  };

  const handleReadQRCode = async (data) => {
    setIsScannerOpen(false);

    try {
      const response = await api.get(
        `/produtos/code/${data}`
      );

      setSelectedProduct(response.data);

      Alert.alert(
        'Produto encontrado',
        `${response.data.nome} foi selecionado.`
      );

    } catch (error) {
      console.log('Erro ao buscar produto:', error);

      Alert.alert(
        'Erro',
        'Produto não encontrado no banco.'
      );
    }
  };

  const handleConfirmEntry = async () => {
    const qtyNum = Number(quantity);
    const valNum = Number(unitValue);

    if (!docNumber) {
      return Alert.alert(
        'Erro',
        'Informe o número do documento/NF.'
      );
    }

    if (!selectedProduct) {
      return Alert.alert(
        'Erro',
        'Selecione um produto.'
      );
    }

    if (
      !quantity ||
      isNaN(qtyNum) ||
      qtyNum <= 0
    ) {
      return Alert.alert(
        'Erro',
        'Quantidade deve ser maior que zero.'
      );
    }

    try {
      const resPedido = await api.post(
        '/pedido-entrada',
        {
          numero_documento: docNumber,
          observacao:
            observation ||
            `Entrada de ${qtyNum}x ${selectedProduct.nome}`,
          id_usuario: 15,
          id_fornecedor: 1,
          data_entrada: new Date()
            .toISOString()
            .slice(0, 10),
          status: 'finalizado'
        }
      );

      const idPedido =
        resPedido.data.id_pedido_entrada ||
        resPedido.data.insertId;

      await api.post(
        '/item-pedido-entrada',
        {
          id_pedido_entrada: idPedido,
          id_produto: selectedProduct.id_produto,
          id_localizacao: 1,
          quantidade: qtyNum,
          valor_unitario: valNum || 0,
          valor_total:
            qtyNum * (valNum || 0)
        }
      );

      Alert.alert(
        'Sucesso',
        'Entrada gravada com sucesso!',
        [
          {
            text: 'OK',
            onPress: () =>
              navigation.navigate('Home')
          }
        ]
      );

    } catch (error) {
      console.log(
        'Erro ao registrar entrada:',
        error
      );

      Alert.alert(
        'Erro',
        'Falha ao processar a entrada.'
      );
    }
  };

  return (
    <View style={styles.container}>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
      >

        <Text style={styles.title}>
          Lançar Entrada
        </Text>

        <Text style={styles.subtitle}>
          Registre a entrada de produtos no estoque
        </Text>

        <TouchableOpacity
          style={styles.qrButton}
          onPress={() => setIsScannerOpen(true)}
        >
          <Text style={styles.qrButtonText}>
            Escanear QR Code
          </Text>
        </TouchableOpacity>

        {selectedProduct && (
          <View style={styles.productSelected}>

            <Text style={styles.productSelectedLabel}>
              Produto selecionado
            </Text>

            <Text style={styles.productSelectedName}>
              {selectedProduct.nome}
            </Text>

            <Text style={styles.productSelectedCode}>
              Código: {selectedProduct.codigo}
            </Text>

          </View>
        )}

        <Text style={styles.label}>
          Número Documento / NF *
        </Text>

        <TextInput
          style={styles.input}
          placeholder="Ex: NF-2024-001"
          placeholderTextColor="#94A3B8"
          value={docNumber}
          onChangeText={setDocNumber}
        />

        <Text style={styles.label}>
          Quantidade *
        </Text>

        <TextInput
          style={styles.input}
          placeholder="Ex: 100"
          keyboardType="numeric"
          placeholderTextColor="#94A3B8"
          value={quantity}
          onChangeText={setQuantity}
        />

        <Text style={styles.label}>
          Valor Unitário (R$)
        </Text>

        <TextInput
          style={styles.input}
          placeholder="Ex: 15.50"
          keyboardType="numeric"
          placeholderTextColor="#94A3B8"
          value={unitValue}
          onChangeText={setUnitValue}
        />

        <Text style={styles.label}>
          Observação
        </Text>

        <TextInput
          style={styles.input}
          placeholder="Opcional"
          placeholderTextColor="#94A3B8"
          value={observation}
          onChangeText={setObservation}
        />

        <TouchableOpacity
          style={styles.button}
          onPress={handleConfirmEntry}
        >
          <Text style={styles.buttonText}>
            Confirmar Entrada
          </Text>
        </TouchableOpacity>

      </ScrollView>

      <QRCodeScannerModal
        visible={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onReadCode={handleReadQRCode}
      />

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#020617'
  },

  content: {
    paddingHorizontal: 20,
    paddingTop: 50,
    paddingBottom: 40
  },

  title: {
    color: '#fff',
    fontSize: 26,
    fontWeight: 'bold'
  },

  subtitle: {
    color: '#94A3B8',
    fontSize: 14,
    marginTop: 5,
    marginBottom: 20
  },

  label: {
    color: '#94A3B8',
    fontSize: 14,
    marginTop: 15,
    marginBottom: 6
  },

  input: {
    backgroundColor: '#1E293B',
    height: 50,
    borderRadius: 12,
    paddingHorizontal: 15,
    color: '#fff'
  },

  qrButton: {
    backgroundColor: '#2563EB',
    height: 52,
    borderRadius: 14,
    marginTop: 5,
    justifyContent: 'center',
    alignItems: 'center'
  },

  qrButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold'
  },

  productSelected: {
    backgroundColor: '#0F172A',
    borderRadius: 14,
    padding: 15,
    marginTop: 15
  },

  productSelectedLabel: {
    color: '#94A3B8',
    fontSize: 12
  },

  productSelectedName: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 5
  },

  productSelectedCode: {
    color: '#38BDF8',
    fontSize: 14,
    marginTop: 5
  },

  button: {
    backgroundColor: '#16A34A',
    height: 52,
    borderRadius: 14,
    marginTop: 30,
    justifyContent: 'center',
    alignItems: 'center'
  },

  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold'
  }
});