import React, { useMemo } from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import { BarChart } from 'react-native-gifted-charts';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../context/ThemeContext';

const screenWidth = Dimensions.get('window').width;

const AZURE_PALETTE = [
  '#0078d4',
  '#106ebe',
  '#005a9e',
  '#004578',
  '#2899f5',
  '#00b7c3',
  '#0284c7',
  '#0369a1',
];

export default function DashboardCharts({ resumo, historicoCompleto = [] }) {
  const { theme } = useTheme();
  const modulos = resumo.modulos || {};

  // 1. Gráfico de Movimentações (Entradas vs. Saídas)
  const dadosMovimentacoes = useMemo(() => {
    let dias = Array.isArray(resumo.movimentacoesPorDia)
      ? resumo.movimentacoesPorDia
      : [];

    // Fallback: se o backend ainda não enviou movimentacoesPorDia, agrupa pelo /history
    if (dias.length === 0 && historicoCompleto.length > 0) {
      const mapa = {};
      historicoCompleto.forEach((mov) => {
        const rawDate = mov.created_at || mov.date;
        if (!rawDate) return;
        const d = new Date(rawDate);
        if (isNaN(d.getTime())) return;

        const label = d.toLocaleDateString('pt-BR', {
          day: '2-digit',
          month: '2-digit',
        });

        if (!mapa[label]) {
          mapa[label] = { label, entrada: 0, saida: 0, ts: d.getTime() };
        }

        const tipo = (mov.type || mov.tipo || '').toLowerCase();
        const qtd = Number(mov.quantidade) || 0;

        if (tipo.includes('entrada')) {
          mapa[label].entrada += qtd;
        } else {
          mapa[label].saida += qtd;
        }
      });

      dias = Object.values(mapa)
        .sort((a, b) => a.ts - b.ts)
        .slice(-6);
    }

    const barras = [];
    dias.forEach((dia) => {
      barras.push({
        value: Number(dia.entrada) || 0,
        label: dia.label,
        spacing: 4,
        labelWidth: 38,
        labelTextStyle: {
          color: theme.textSecondary,
          fontSize: 10,
          fontWeight: '600',
        },
        frontColor: '#2899f5', // Azul claro Azure = Entradas
        barBorderTopLeftRadius: 5,
        barBorderTopRightRadius: 5,
      });
      barras.push({
        value: Number(dia.saida) || 0,
        frontColor: '#004578', // Azul profundo Azure = Saídas
        barBorderTopLeftRadius: 5,
        barBorderTopRightRadius: 5,
      });
    });

    return barras;
  }, [resumo.movimentacoesPorDia, historicoCompleto, theme.textSecondary]);

  // 2. Gráfico dos 8 módulos do banco (igual ao dbGraficoGeral da Web)
  const dadosModulos = useMemo(() => {
    const itens = [
      { label: 'Prod.', value: Number(modulos.produtos) || 0 },
      { label: 'Estoq.', value: Number(modulos.estoque) || 0 },
      { label: 'Entr.', value: Number(modulos.entradas) || 0 },
      { label: 'Saíd.', value: Number(modulos.saidas) || 0 },
      { label: 'Usuár.', value: Number(modulos.usuarios) || 0 },
      { label: 'Sens.', value: Number(modulos.sensores) || 0 },
      { label: 'Camin.', value: Number(modulos.caminhoes) || 0 },
      { label: 'Fornec.', value: Number(modulos.fornecedores) || 0 },
    ];

    return itens.map((item, idx) => ({
      value: item.value,
      label: item.label,
      frontColor: AZURE_PALETTE[idx % AZURE_PALETTE.length],
      barBorderTopLeftRadius: 6,
      barBorderTopRightRadius: 6,
      labelTextStyle: {
        color: theme.textSecondary,
        fontSize: 10,
        fontWeight: '600',
      },
    }));
  }, [modulos, theme.textSecondary]);

  return (
    <View style={styles.wrapper}>
      {/* CARD HERO AZURE DARK */}
      <View style={styles.heroCard}>
        <View style={styles.heroTopRow}>
          <View style={styles.heroBadgeRow}>
            <Ionicons name="swap-vertical" size={14} color="#60a5fa" />
            <Text style={styles.heroBadgeText}>FLUXO DE MOVIMENTAÇÕES</Text>
          </View>
          <View style={styles.heroPill}>
            <Text style={styles.heroPillText}>Enterprise</Text>
          </View>
        </View>

        <View style={styles.heroMetricsRow}>
          <View style={styles.heroMetricCol}>
            <Text style={styles.heroCaption}>PEDIDOS ENTRADA</Text>
            <Text style={styles.heroQuantumVal}>{modulos.entradas ?? 0}</Text>
          </View>

          <View style={styles.heroDivider} />

          <View style={styles.heroMetricCol}>
            <Text style={styles.heroCaption}>PEDIDOS SAÍDA</Text>
            <Text style={styles.heroHexVal}>{modulos.saidas ?? 0}</Text>
          </View>

          <View style={styles.heroDivider} />

          <View style={styles.heroMetricCol}>
            <Text style={styles.heroCaption}>SALDO TOTAL</Text>
            <Text style={styles.heroQuantumVal}>{resumo.totalProducts ?? 0}</Text>
          </View>
        </View>
      </View>

      {/* GRÁFICO 1: MOVIMENTAÇÕES (ENTRADAS VS. SAÍDAS) */}
      <View
        style={[
          styles.chartCard,
          { backgroundColor: theme.card, borderColor: theme.border },
        ]}
      >
        <View style={styles.cardTopGlow} />
        <View style={styles.barHeader}>
          <View>
            <Text style={[styles.chartTitle, { color: theme.textPrimary }]}>
              Movimentações de Estoque
            </Text>
            <Text style={[styles.chartSubtitle, { color: theme.textSecondary }]}>
              Entradas e saídas registradas por data
            </Text>
          </View>

          <View style={styles.inlineLegend}>
            <View style={styles.inlineLegendItem}>
              <View style={[styles.smallDot, { backgroundColor: '#2899f5' }]} />
              <Text style={[styles.smallLegendText, { color: theme.textSecondary }]}>
                Entradas
              </Text>
            </View>
            <View style={styles.inlineLegendItem}>
              <View style={[styles.smallDot, { backgroundColor: '#004578' }]} />
              <Text style={[styles.smallLegendText, { color: theme.textSecondary }]}>
                Saídas
              </Text>
            </View>
          </View>
        </View>

        {dadosMovimentacoes.length === 0 ? (
          <Text style={[styles.emptyChartText, { color: theme.textSecondary }]}>
            Nenhuma entrada ou saída registrada no banco ainda.
          </Text>
        ) : (
          <BarChart
            data={dadosMovimentacoes}
            width={screenWidth - 108}
            height={165}
            barWidth={14}
            spacing={22}
            noOfSections={4}
            yAxisThickness={0}
            xAxisThickness={1}
            xAxisColor={theme.border}
            rulesColor={theme.border}
            rulesType="solid"
            yAxisTextStyle={{ color: theme.textSecondary, fontSize: 11 }}
            isAnimated
          />
        )}
      </View>

      {/* GRÁFICO 2: MÉTRICAS CONSOLIDADAS DO BANCO */}
      <View
        style={[
          styles.chartCard,
          { backgroundColor: theme.card, borderColor: theme.border },
        ]}
      >
        <View style={styles.cardTopGlow} />
        <Text style={[styles.chartTitle, { color: theme.textPrimary }]}>
          Métricas Consolidadas do Banco
        </Text>
        <Text style={[styles.chartSubtitle, { color: theme.textSecondary }]}>
          Contagem total dos registros por módulo
        </Text>

        <BarChart
          data={dadosModulos}
          width={screenWidth - 108}
          height={165}
          barWidth={18}
          spacing={14}
          noOfSections={4}
          yAxisThickness={0}
          xAxisThickness={1}
          xAxisColor={theme.border}
          rulesColor={theme.border}
          rulesType="solid"
          yAxisTextStyle={{ color: theme.textSecondary, fontSize: 11 }}
          isAnimated
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    marginBottom: 24,
    gap: 16,
  },
  heroCard: {
    backgroundColor: '#091424',
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: 'rgba(40, 153, 245, 0.28)',
  },
  heroTopRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  heroBadgeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  heroBadgeText: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1,
    color: '#60a5fa',
  },
  heroPill: {
    backgroundColor: 'rgba(40, 153, 245, 0.2)',
    borderWidth: 1,
    borderColor: 'rgba(96, 165, 250, 0.4)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
  },
  heroPillText: {
    color: '#93c5fd',
    fontSize: 11,
    fontWeight: '700',
  },
  heroMetricsRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  heroMetricCol: {
    flex: 1,
  },
  heroDivider: {
    width: 1,
    height: 36,
    backgroundColor: 'rgba(255, 255, 255, 0.14)',
    marginHorizontal: 10,
  },
  heroCaption: {
    fontSize: 9,
    fontWeight: '700',
    letterSpacing: 0.6,
    color: '#94a3b8',
    marginBottom: 4,
  },
  heroQuantumVal: {
    fontSize: 20,
    fontWeight: '900',
    color: '#60a5fa',
  },
  heroHexVal: {
    fontSize: 20,
    fontWeight: '900',
    color: '#38bdf8',
  },
  chartCard: {
    borderRadius: 14,
    padding: 18,
    borderWidth: 1,
    overflow: 'hidden',
  },
  cardTopGlow: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 4,
    backgroundColor: '#0078d4',
  },
  barHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  chartTitle: {
    fontSize: 16,
    fontWeight: '800',
    marginTop: 2,
  },
  chartSubtitle: {
    fontSize: 12,
    marginTop: 2,
    marginBottom: 16,
  },
  inlineLegend: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 4,
  },
  inlineLegendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  smallDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  smallLegendText: {
    fontSize: 11,
    fontWeight: '600',
  },
  emptyChartText: {
    fontSize: 13,
    textAlign: 'center',
    paddingVertical: 24,
  },
});