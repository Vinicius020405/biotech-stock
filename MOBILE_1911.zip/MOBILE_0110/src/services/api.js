
import { API_URL } from '../config/apiUrl';
import * as SecureStore from 'expo-secure-store';

// Endereço único utilizado por todo o aplicativo
const BASE_URL = `${API_URL}/api`;

// Monta o endereço completo sem duplicar /api
const getFullUrl = (endpoint) => {
  if (endpoint.startsWith('/api/')) {
    return `${API_URL}${endpoint}`;
  }

  return `${BASE_URL}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`;
};

// Busca o token JWT salvo durante o login
const getAuthHeaders = async (extraHeaders = {}) => {
  const token = await SecureStore.getItemAsync('stockpro_token');

  return {
    'Content-Type': 'application/json',
    ...extraHeaders,
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

// Trata as respostas do servidor
const handleResponse = async (response) => {
  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const error = new Error(
      data.message || data.error || `Erro na requisição: ${response.status}`
    );

    error.response = {
      status: response.status,
      data,
    };

    throw error;
  }

  return { data };
};

const api = {
  get: async (endpoint) => {
    const headers = await getAuthHeaders();

    const response = await fetch(getFullUrl(endpoint), {
      method: 'GET',
      headers,
    });

    return handleResponse(response);
  },

  post: async (endpoint, body) => {
    const headers = await getAuthHeaders();

    const response = await fetch(getFullUrl(endpoint), {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
    });

    return handleResponse(response);
  },

  put: async (endpoint, body) => {
    const headers = await getAuthHeaders();

    const response = await fetch(getFullUrl(endpoint), {
      method: 'PUT',
      headers,
      body: JSON.stringify(body),
    });

    return handleResponse(response);
  },

  delete: async (endpoint) => {
    const headers = await getAuthHeaders();

    const response = await fetch(getFullUrl(endpoint), {
      method: 'DELETE',
      headers,
    });

    return handleResponse(response);
  },
};

export default api;
