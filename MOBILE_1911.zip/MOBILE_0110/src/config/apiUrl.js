import Constants from 'expo-constants';

const PORTA_API = 3000;

// Se um dia o auto-detect falhar, coloque o IP aqui manualmente
const IP_MANUAL = null; // ex.: '10.135.60.84'

function descobrirHost() {
  if (IP_MANUAL) return IP_MANUAL;

  // Ex.: "10.135.60.84:8081" -> pega só o IP
  const hostUri =
    Constants.expoConfig?.hostUri ||
    Constants.expoGoConfig?.debuggerHost ||
    Constants.manifest2?.extra?.expoGo?.debuggerHost;

  if (hostUri) return hostUri.split(':')[0];

  return 'localhost';
}

export const API_URL = `http://${descobrirHost()}:${PORTA_API}`;