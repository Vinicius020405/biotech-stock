const jwt = require('jsonwebtoken');

function authenticateToken(req, res, next) {
  // Verifica se o JWT_SECRET está configurado
  if (!process.env.JWT_SECRET) {
    console.error('JWT_SECRET não configurada no .env');

    return res.status(500).json({
      success: false,
      message: 'Erro na configuração de segurança do servidor.'
    });
  }

  // Busca o cabeçalho Authorization
  const authHeader = req.headers.authorization;

  // Verifica se o formato é Bearer TOKEN
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      message: 'Acesso negado. Token não fornecido.'
    });
  }

  // Extrai o token
  const token = authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Token não fornecido.'
    });
  }

  try {
    // Valida o token JWT
    const usuario = jwt.verify(token, process.env.JWT_SECRET);

    // Disponibiliza os dados do usuário nas rotas protegidas
    req.user = usuario;

    // Continua a execução da rota
    next();

  } catch (error) {
    console.error('Erro ao validar JWT:', error.message);

    return res.status(403).json({
      success: false,
      message: 'Token inválido ou expirado.'
    });
  }
}

module.exports = authenticateToken;
