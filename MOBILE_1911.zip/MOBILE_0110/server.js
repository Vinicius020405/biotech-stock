require('dotenv').config(); // Carregado na 1ª linha

const express = require('express');
const mysql = require('mysql2/promise'); // Mantido apenas a versão com suporte a Promises
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const authenticateToken = require('./middlewares/auth');

const app = express();

// Configuração de Middlewares
app.use(cors());
app.use(express.json());

// Conexão com o Banco de Dados MySQL usando variáveis de ambiente
const db = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT ? Number(process.env.DB_PORT) : 3306,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
});

// Rota de Teste
app.get('/', (req, res) => {
  res.send('Servidor do Backend funcionando e acessível!');
});

// --- AUTENTICAÇÃO ---

const handleLogin = async (req, res) => {
  const { email, senha } = req.body;

  try {
    const [rows] = await db.query(
      `SELECT 
        id_usuario,
        nome,
        email,
        senha,
        perfil,
        status,
        plano,
        criado_em
      FROM usuarios
      WHERE email = ?`,
      [email]
    );

    if (rows.length === 0) {
      return res.status(401).json({
        success: false,
        message: 'Credenciais inválidas.'
      });
    }

    const user = rows[0];
    const senhaValida = await bcrypt.compare(
      senha,
      user.senha || ''
    );

    if (!senhaValida) {
      return res.status(401).json({
        success: false,
        message: 'Credenciais inválidas.'
      });
    }

    delete user.senha;

    const token = jwt.sign(
      { id: user.id_usuario, email: user.email, perfil: user.perfil },
      process.env.JWT_SECRET,
      { expiresIn: '8h' }
    );

    res.json({
      success: true,
      user,
      token
    });

  } catch (error) {
    console.error('Erro no login:', error);
    res.status(500).json({ error: error.message });
  }
};

app.post('/api/login', handleLogin);
app.post('/login', handleLogin);

// --- RECUPERAÇÃO DE SENHA (ROTAS PÚBLICAS - ANTES DO authenticateToken) ---

// Armazena temporariamente: email -> { codigo, expiraEm, tentativas }
const codigosRecuperacao = new Map();

app.post('/verificar-email', async (req, res) => {
  const { email } = req.body;

  if (!email) {
    return res.status(400).json({ message: 'Informe o e-mail.' });
  }

  const emailNormalizado = email.trim().toLowerCase();

  try {
    const [rows] = await db.query(
      'SELECT id_usuario, email FROM usuarios WHERE LOWER(TRIM(email)) = ?',
      [emailNormalizado]
    );

    if (!rows || rows.length === 0) {
      return res.status(404).json({ message: 'E-mail não encontrado no sistema.' });
    }

    // Gera código aleatório de 6 dígitos válido por 10 minutos
    const codigo = Math.floor(100000 + Math.random() * 900000).toString();
    codigosRecuperacao.set(emailNormalizado, {
      codigo,
      expiraEm: Date.now() + 10 * 60 * 1000,
      tentativas: 0
    });

    // Exibe no terminal do servidor para testes locais (substituir por Nodemailer em produção)
    console.log(`[RECUPERAÇÃO DE SENHA] Código para ${emailNormalizado}: ${codigo}`);

    return res.status(200).json({
      sucesso: true,
      message: 'Código de verificação enviado para o e-mail informado.'
    });
  } catch (error) {
    console.error('ERRO NO BANCO DE DADOS:', error);
    return res.status(500).json({ message: 'Erro ao consultar a base de dados.' });
  }
});

app.post('/redefinir-senha', async (req, res) => {
  const { email, codigo, novaSenha } = req.body;

  if (!email || !codigo || !novaSenha) {
    return res.status(400).json({
      message: 'E-mail, código de verificação e nova senha são obrigatórios.'
    });
  }

  if (novaSenha.length < 8) {
    return res.status(400).json({
      message: 'A nova senha deve ter pelo menos 8 caracteres.'
    });
  }

  const emailNormalizado = email.trim().toLowerCase();
  const registro = codigosRecuperacao.get(emailNormalizado);

  if (!registro) {
    return res.status(400).json({
      message: 'Solicite um código de verificação antes de redefinir a senha.'
    });
  }

  if (Date.now() > registro.expiraEm) {
    codigosRecuperacao.delete(emailNormalizado);
    return res.status(400).json({
      message: 'Código expirado. Solicite um novo código.'
    });
  }

  if (registro.tentativas >= 5) {
    codigosRecuperacao.delete(emailNormalizado);
    return res.status(429).json({
      message: 'Muitas tentativas incorretas. Solicite um novo código.'
    });
  }

  if (String(codigo).trim() !== registro.codigo) {
    registro.tentativas += 1;
    return res.status(401).json({
      message: 'Código de verificação inválido.'
    });
  }

  try {
    const novaSenhaHash = await bcrypt.hash(novaSenha, 12);

    const [result] = await db.query(
      'UPDATE usuarios SET senha = ? WHERE LOWER(TRIM(email)) = ?',
      [novaSenhaHash, emailNormalizado]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Usuário não encontrado para atualizar.' });
    }

    // Invalida o código imediatamente após o uso
    codigosRecuperacao.delete(emailNormalizado);

    return res.status(200).json({
      success: true,
      message: 'Senha alterada com sucesso!'
    });
  } catch (error) {
    console.error('ERRO AO ALTERAR SENHA:', error);
    return res.status(500).json({ message: 'Erro no servidor ao atualizar a senha.' });
  }
});

// --- PROTEÇÃO DAS ROTAS PRIVADAS ---
app.use(authenticateToken);

// --- PRODUTOS ---

const handleGetProdutos = async (req, res) => {
  try {
    const [produtos] = await db.query(`
      SELECT
        id_produto,
        codigo,
        nome,
        descricao,
        unidade_medida,
        estoque_minimo,
        estoque_maximo,
        status,
        criado_em,
        imagem_tipo,
        imagem_nome, 
        imagem_blob
      FROM produto
      ORDER BY nome ASC
    `);

    res.json(produtos);

  } catch (error) {
    console.error('Erro ao buscar produtos:', error);
    res.status(500).json({ error: error.message });
  }
};

app.get('/api/produtos', handleGetProdutos);
app.get('/produtos', handleGetProdutos);

// BUSCAR PRODUTO PELO QR CODE
const handleGetProdutoByCode = async (req, res) => {
  const { code } = req.params;

  try {
    const [rows] = await db.query(`
      SELECT
        p.id_produto,
        p.codigo,
        p.nome,
        p.descricao,
        p.unidade_medida,
        p.estoque_minimo,
        p.estoque_maximo,
        p.status,
        COALESCE(SUM(e.quantidade_atual), 0) AS quantidade_estoque
      FROM produto p
      LEFT JOIN estoque e
        ON p.id_produto = e.id_produto
      WHERE p.codigo = ?
         OR CAST(p.id_produto AS CHAR) = ?
      GROUP BY
        p.id_produto,
        p.codigo,
        p.nome,
        p.descricao,
        p.unidade_medida,
        p.estoque_minimo,
        p.estoque_maximo,
        p.status
    `, [code, code]);

    if (rows.length === 0) {
      return res.status(404).json({ message: 'Produto não encontrado.' });
    }

    res.json(rows[0]);
  } catch (error) {
    console.error('Erro ao buscar produto pelo QR Code:', error);
    res.status(500).json({ error: error.message });
  }
};

app.get('/api/produtos/code/:code', handleGetProdutoByCode);
app.get('/produtos/code/:code', handleGetProdutoByCode);

// BUSCAR PRODUTO POR ID OU CÓDIGO
app.get('/api/products/:identifier', async (req, res) => {
  const { identifier } = req.params;

  try {
    const [rows] = await db.query(`
      SELECT
        p.id_produto,
        p.codigo,
        p.nome,
        p.descricao,
        p.unidade_medida,
        p.estoque_minimo,
        p.estoque_maximo,
        p.status,
        COALESCE(SUM(e.quantidade_atual), 0) AS quantidade_estoque
      FROM produto p
      LEFT JOIN estoque e
        ON p.id_produto = e.id_produto
      WHERE p.id_produto = ?
         OR p.codigo = ?
      GROUP BY
        p.id_produto,
        p.codigo,
        p.nome,
        p.descricao,
        p.unidade_medida,
        p.estoque_minimo,
        p.estoque_maximo,
        p.status
    `, [identifier, identifier]);

    if (rows.length > 0) {
      return res.json(rows[0]);
    }

    res.status(404).json({ message: 'Produto não encontrado.' });

  } catch (error) {
    console.error('Erro ao buscar produto:', error);
    res.status(500).json({ error: error.message });
  }
});


// --- CAMINHÕES ---

const handleGetCaminhoes = async (req, res) => {
  try {
    const [caminhoes] = await db.query(`
      SELECT
        id_caminhao,
        placa,
        modelo,
        cor,
        marca,
        chassi,
        imagem_nome,
        imagem_tipo,
        imagem_blob
      FROM caminhao
      ORDER BY id_caminhao DESC
    `);

    const resultado = caminhoes.map(caminhao => ({
      id_caminhao: caminhao.id_caminhao,
      placa: caminhao.placa,
      modelo: caminhao.modelo,
      cor: caminhao.cor,
      marca: caminhao.marca,
      chassi: caminhao.chassi,
      imagem_nome: caminhao.imagem_nome,
      imagem_tipo: caminhao.imagem_tipo,
      imagem: caminhao.imagem_blob
        ? caminhao.imagem_blob.toString('base64')
        : null
    }));

    res.json(resultado);

  } catch (error) {
    console.error('Erro ao buscar caminhões:', error);
    res.status(500).json({ error: error.message });
  }
};

app.get('/api/caminhoes', handleGetCaminhoes);
app.get('/caminhoes', handleGetCaminhoes);


// --- ESTOQUE ---

const handleGetEstoque = async (req, res) => {
  try {
    const [estoque] = await db.query(`
      SELECT
        e.id_estoque,
        e.id_produto,
        e.id_localizacao,
        e.quantidade_atual,
        e.atualizado_em,
        p.codigo,
        p.nome AS produto_nome,
        p.unidade_medida,
        p.estoque_minimo,
        p.estoque_maximo,
        l.nome AS localizacao_nome,
        l.setor
      FROM estoque e
      INNER JOIN produto p
        ON e.id_produto = p.id_produto
      LEFT JOIN localizacao l
        ON e.id_localizacao = l.id_localizacao
      ORDER BY e.id_estoque ASC
    `);

    res.json(estoque);

  } catch (error) {
    console.error('Erro ao buscar estoque:', error);
    res.status(500).json({ error: error.message });
  }
};

app.get('/api/estoque', handleGetEstoque);
app.get('/estoque', handleGetEstoque);
app.get('/api/stock', handleGetEstoque);


// --- FORNECEDORES ---

const handleGetFornecedores = async (req, res) => {
  try {
    const [fornecedores] = await db.query(`
      SELECT
        id_fornecedor,
        nome,
        cnpj,
        email,
        telefone,
        endereco,
        cep,
        contato_responsavel,
        status,
        observacoes
      FROM fornecedor
      ORDER BY nome ASC
    `);

    res.json(fornecedores);

  } catch (error) {
    console.error('Erro ao buscar fornecedores:', error);
    res.status(500).json({ error: error.message });
  }
};

app.get('/api/fornecedores', handleGetFornecedores);
app.get('/fornecedores', handleGetFornecedores);


// --- LOCALIZAÇÕES ---

const handleGetLocations = async (req, res) => {
  try {
    const [locations] = await db.query(`
      SELECT
        id_localizacao,
        nome,
        setor,
        corredor,
        prateleira,
        observacao
      FROM localizacao
      ORDER BY nome ASC
    `);

    res.json(locations);

  } catch (error) {
    console.error('Erro ao buscar localizações:', error);
    res.status(500).json({ error: error.message });
  }
};

app.get('/api/locations', handleGetLocations);
app.get('/locations', handleGetLocations);


// --- SENSORES ---

const handleGetSensores = async (req, res) => {
  try {
    const [sensores] = await db.query(`
      SELECT
        id_sensor,
        nome,
        tipo_sensor,
        codigo_sensor,
        id_localizacao,
        id_produto,
        status,
        criado_em
      FROM cadastro_sensor
      ORDER BY nome ASC
    `);

    res.json(sensores);

  } catch (error) {
    console.error('Erro ao buscar sensores:', error);
    res.status(500).json({ error: error.message });
  }
};

app.get('/api/sensores', handleGetSensores);
app.get('/sensores', handleGetSensores);


// --- PEDIDO DE ENTRADA ---

const handleGetPedidoEntrada = async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT 
        id_pedido_entrada,
        numero_documento,
        data_entrada,
        id_usuario,
        observacao,
        status,
        id_fornecedor,
        criado_em
      FROM pedido_entrada
      ORDER BY id_pedido_entrada DESC
    `);
    res.json(rows);
  } catch (error) {
    console.error('Erro ao buscar pedidos de entrada:', error);
    res.status(500).json({ error: error.message });
  }
};

app.get('/api/pedido-entrada', handleGetPedidoEntrada);
app.get('/pedido-entrada', handleGetPedidoEntrada);

const handlePostPedidoEntrada = async (req, res) => {
  const {
    numero_documento,
    data_entrada,
    id_usuario,
    observacao,
    fornecedor,
    status,
    id_fornecedor
  } = req.body;

  try {
    const obsFinal = observacao || (fornecedor ? `Fornecedor: ${fornecedor}` : null);

    const [result] = await db.query(`
      INSERT INTO pedido_entrada
      (
        numero_documento,
        data_entrada,
        id_usuario,
        observacao,
        status,
        id_fornecedor
      )
      VALUES (?, ?, ?, ?, ?, ?)
    `, [
      numero_documento || null,
      data_entrada || new Date().toISOString().slice(0, 10),
      id_usuario || null,
      obsFinal,
      status || 'finalizado',
      id_fornecedor || null
    ]);

    res.json({
      success: true,
      id_pedido_entrada: result.insertId
    });

  } catch (error) {
    console.error('Erro ao criar pedido de entrada:', error);
    res.status(500).json({ error: error.message });
  }
};

app.post('/api/pedido-entrada', handlePostPedidoEntrada);
app.post('/pedido-entrada', handlePostPedidoEntrada);

const handlePostItemPedidoEntrada = async (req, res) => {
  const {
    id_pedido_entrada,
    id_produto,
    id_localizacao,
    quantidade,
    valor_unitario,
    valor_total
  } = req.body;

  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    await connection.query(`
      INSERT INTO item_pedido_entrada
      (
        id_pedido_entrada,
        id_produto,
        id_localizacao,
        quantidade,
        valor_unitario,
        valor_total
      )
      VALUES (?, ?, ?, ?, ?, ?)
    `, [
      id_pedido_entrada,
      id_produto,
      id_localizacao,
      quantidade,
      valor_unitario || 0,
      valor_total || 0
    ]);

    const [estoqueExistente] = await connection.query(`
      SELECT id_estoque
      FROM estoque
      WHERE id_produto = ?
        AND id_localizacao = ?
      LIMIT 1
    `, [
      id_produto,
      id_localizacao
    ]);

    if (estoqueExistente.length > 0) {
      await connection.query(`
        UPDATE estoque
        SET quantidade_atual = quantidade_atual + ?
        WHERE id_estoque = ?
      `, [
        quantidade,
        estoqueExistente[0].id_estoque
      ]);
    } else {
      await connection.query(`
        INSERT INTO estoque
        (
          id_produto,
          id_localizacao,
          quantidade_atual
        )
        VALUES (?, ?, ?)
      `, [
        id_produto,
        id_localizacao,
        quantidade
      ]);
    }

    await connection.commit();

    res.json({
      success: true,
      message: 'Item de entrada registrado com sucesso.'
    });

  } catch (error) {
    await connection.rollback();
    console.error('Erro ao criar item de entrada:', error);
    res.status(500).json({ error: error.message });
  } finally {
    connection.release();
  }
};

app.post('/api/item-pedido-entrada', handlePostItemPedidoEntrada);
app.post('/item-pedido-entrada', handlePostItemPedidoEntrada);


// --- PEDIDO DE SAÍDA ---

const handleGetPedidoSaida = async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT 
        id_pedido_saida,
        numero_documento,
        solicitante,
        data_saida,
        id_usuario,
        id_caminhao,
        status,
        criado_em
      FROM pedido_saida
      ORDER BY id_pedido_saida DESC
    `);
    res.json(rows);
  } catch (error) {
    console.error('Erro ao buscar pedidos de saída:', error);
    res.status(500).json({ error: error.message });
  }
};

app.get('/api/pedido-saida', handleGetPedidoSaida);
app.get('/pedido-saida', handleGetPedidoSaida);

const handlePostPedidoSaida = async (req, res) => {
  const {
    numero_documento,
    solicitante,
    data_saida,
    id_usuario,
    id_caminhao,
    status,
    id_produto,
    id_localizacao,
    quantidade,
    itens
  } = req.body;

  let conn;
  try {
    conn = await db.getConnection();
    await conn.beginTransaction();

    const [result] = await conn.query(`
      INSERT INTO pedido_saida
      (
        numero_documento,
        solicitante,
        data_saida,
        id_usuario,
        id_caminhao,
        status
      )
      VALUES (?, ?, ?, ?, ?, ?)
    `, [
      numero_documento || null,
      solicitante || null,
      data_saida || new Date().toISOString().slice(0, 10),
      id_usuario || null,
      id_caminhao || null,
      status || 'finalizado'
    ]);

    const id_pedido_saida = result.insertId;

    let listaItens = [];
    if (Array.isArray(itens) && itens.length > 0) {
      listaItens = itens;
    } else if (id_produto && id_localizacao && quantidade) {
      listaItens = [{ id_produto, id_localizacao, quantidade }];
    }

    for (const item of listaItens) {
      const qtd = Number(item.quantidade);

      await conn.query(`
        INSERT INTO item_pedido_saida (id_pedido_saida, id_produto, id_localizacao, quantidade)
        VALUES (?, ?, ?, ?)
      `, [id_pedido_saida, item.id_produto, item.id_localizacao, qtd]);

      // CORRIGIDO: quantidade -> quantidade_atual
      await conn.query(`
        UPDATE estoque
        SET quantidade_atual = quantidade_atual - ?
        WHERE id_produto = ? AND id_localizacao = ?
      `, [qtd, item.id_produto, item.id_localizacao]);
    }

    await conn.commit();

    res.json({
      success: true,
      message: 'Saída registrada e estoque atualizado com sucesso!',
      id_pedido_saida: id_pedido_saida
    });

  } catch (error) {
    if (conn) await conn.rollback();
    console.error('Erro ao criar pedido de saída:', error);
    res.status(500).json({ error: error.message });
  } finally {
    if (conn) conn.release();
  }
};

app.post('/api/pedido-saida', handlePostPedidoSaida);
app.post('/pedido-saida', handlePostPedidoSaida);

const handlePostItemPedidoSaida = async (req, res) => {
  const {
    id_pedido_saida,
    id_produto,
    id_localizacao,
    quantidade
  } = req.body;

  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    const [estoque] = await connection.query(`
      SELECT
        id_estoque,
        quantidade_atual
      FROM estoque
      WHERE id_produto = ?
        AND id_localizacao = ?
      LIMIT 1
    `, [
      id_produto,
      id_localizacao
    ]);

    if (estoque.length === 0) {
      await connection.rollback();
      return res.status(400).json({
        message: 'Estoque não encontrado para esse produto e localização.'
      });
    }

    if (Number(estoque[0].quantidade_atual) < Number(quantidade)) {
      await connection.rollback();
      return res.status(400).json({
        message: 'Estoque insuficiente.'
      });
    }

    await connection.query(`
      INSERT INTO item_pedido_saida
      (
        id_pedido_saida,
        id_produto,
        id_localizacao,
        quantidade
      )
      VALUES (?, ?, ?, ?)
    `, [
      id_pedido_saida,
      id_produto,
      id_localizacao,
      quantidade
    ]);

    await connection.query(`
      UPDATE estoque
      SET quantidade_atual = quantidade_atual - ?
      WHERE id_estoque = ?
    `, [
      quantidade,
      estoque[0].id_estoque
    ]);

    await connection.commit();

    res.json({
      success: true,
      message: 'Item de saída registrado com sucesso.'
    });

  } catch (error) {
    await connection.rollback();
    console.error('Erro ao criar item de saída:', error);
    res.status(500).json({ error: error.message });
  } finally {
    connection.release();
  }
};

app.post('/api/item-pedido-saida', handlePostItemPedidoSaida);
app.post('/item-pedido-saida', handlePostItemPedidoSaida);


// --- MOVIMENTAÇÃO DE ESTOQUE ---

app.post('/api/stock/move', async (req, res) => {
  const {
    productId,
    locationId,
    type,
    quantity,
    pedidoId
  } = req.body;

  const qtyNum = parseFloat(quantity);

  if (
    !productId ||
    !locationId ||
    !type ||
    isNaN(qtyNum) ||
    qtyNum <= 0
  ) {
    return res.status(400).json({
      message: 'Dados inválidos ou incompletos.'
    });
  }

  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    if (type === 'Entrada') {
      const [estoque] = await connection.query(`
        SELECT id_estoque
        FROM estoque
        WHERE id_produto = ?
          AND id_localizacao = ?
        LIMIT 1
      `, [productId, locationId]);

      if (estoque.length > 0) {
        await connection.query(`
          UPDATE estoque
          SET quantidade_atual = quantidade_atual + ?
          WHERE id_estoque = ?
        `, [qtyNum, estoque[0].id_estoque]);
      } else {
        await connection.query(`
          INSERT INTO estoque
          (id_produto, id_localizacao, quantidade_atual)
          VALUES (?, ?, ?)
        `, [productId, locationId, qtyNum]);
      }

      if (pedidoId) {
        await connection.query(`
          INSERT INTO item_pedido_entrada
          (id_pedido_entrada, id_produto, id_localizacao, quantidade)
          VALUES (?, ?, ?, ?)
        `, [pedidoId, productId, locationId, qtyNum]);
      }

    } else if (type === 'Saída') {
      const [result] = await connection.query(`
        UPDATE estoque
        SET quantidade_atual = quantidade_atual - ?
        WHERE id_produto = ?
          AND id_localizacao = ?
          AND quantidade_atual >= ?
      `, [qtyNum, productId, locationId, qtyNum]);

      if (result.affectedRows === 0) {
        await connection.rollback();
        return res.status(400).json({
          message: 'Estoque insuficiente ou registro não encontrado.'
        });
      }

      if (pedidoId) {
        await connection.query(`
          INSERT INTO item_pedido_saida
          (id_pedido_saida, id_produto, id_localizacao, quantidade)
          VALUES (?, ?, ?, ?)
        `, [pedidoId, productId, locationId, qtyNum]);
      }

    } else {
      await connection.rollback();
      return res.status(400).json({
        message: 'Tipo de movimentação inválido.'
      });
    }

    await connection.commit();

    res.json({
      success: true,
      message: 'Movimentação realizada com sucesso!'
    });

  } catch (error) {
    await connection.rollback();
    console.error('Erro na movimentação:', error);
    res.status(500).json({ error: error.message });
  } finally {
    connection.release();
  }
});


// --- HISTÓRICO ---

const handleGetHistory = async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT * FROM (
        SELECT
          CONCAT('S-', item.id_item_saida) AS id,
          'Saída' AS type,
          item.quantidade,
          ps.data_saida AS date,
          ps.criado_em AS created_at,
          p.nome AS product,
          l.nome AS localizacao
        FROM item_pedido_saida item
        JOIN produto p
          ON item.id_produto = p.id_produto
        JOIN pedido_saida ps
          ON item.id_pedido_saida = ps.id_pedido_saida
        LEFT JOIN localizacao l
          ON item.id_localizacao = l.id_localizacao

        UNION ALL

        SELECT
          CONCAT('E-', item.id_item_entrada) AS id,
          'Entrada' AS type,
          item.quantidade,
          pe.data_entrada AS date,
          pe.criado_em AS created_at,
          p.nome AS product,
          l.nome AS localizacao
        FROM item_pedido_entrada item
        JOIN produto p
          ON item.id_produto = p.id_produto
        JOIN pedido_entrada pe
          ON item.id_pedido_entrada = pe.id_pedido_entrada
        LEFT JOIN localizacao l
          ON item.id_localizacao = l.id_localizacao
      ) AS historico_completo
      ORDER BY created_at DESC, date DESC
    `);

    res.json(rows);

  } catch (error) {
    console.error('Erro no histórico:', error);
    res.status(500).json({ error: error.message });
  }
};

app.get('/api/history', handleGetHistory);
app.get('/history', handleGetHistory);
app.get('/api/historico', handleGetHistory);
app.get('/historico', handleGetHistory);


// --- USUÁRIOS E SENHAS ---

app.get('/api/usuarios/:id', async (req, res) => {
  const { id } = req.params;

  // Impede que um usuário consulte os dados de outra conta
  if (Number(req.user.id) !== Number(id)) {
    return res.status(403).json({
      message: 'Você não tem permissão para acessar estes dados.'
    });
  }

  try {
    const [rows] = await db.query(
      'SELECT id_usuario, nome, email, perfil, status, plano FROM usuarios WHERE id_usuario = ?',
      [id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Usuário não encontrado.' });
    }
    res.json(rows[0]);
  } catch (error) {
    console.error('Erro ao buscar usuário:', error);
    res.status(500).json({ error: error.message });
  }
});


app.put('/api/usuarios/:id/senha', authenticateToken, async (req, res) => {
  const { id } = req.params;
  const { senhaAtual, novaSenha } = req.body;

  if (!senhaAtual || !novaSenha) {
    return res.status(400).json({
      message: 'Por favor, preencha a senha atual e a nova senha.'
    });
  }

  if (novaSenha.length < 8) {
    return res.status(400).json({
      message: 'A nova senha deve ter pelo menos 8 caracteres.'
    });
  }

  // Impede que um usuário altere a senha de outra conta
  if (Number(req.user.id) !== Number(id)) {
    return res.status(403).json({
      message: 'Você não tem permissão para alterar esta senha.'
    });
  }

  try {
    const [rows] = await db.query(
      'SELECT id_usuario, senha FROM usuarios WHERE id_usuario = ?',
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({
        message: 'Usuário não encontrado.'
      });
    }

    const usuario = rows[0];

    // Confere a senha atual usando bcrypt
    const senhaValida = await bcrypt.compare(
      senhaAtual,
      usuario.senha || ''
    );

    if (!senhaValida) {
      return res.status(401).json({
        message: 'A senha atual está incorreta.'
      });
    }

    // Gera o hash da nova senha
    const novaSenhaHash = await bcrypt.hash(novaSenha, 12);

    await db.query(
      'UPDATE usuarios SET senha = ? WHERE id_usuario = ?',
      [novaSenhaHash, id]
    );

    return res.json({
      success: true,
      message: 'Senha alterada com sucesso!'
    });

  } catch (error) {
    console.error('Erro ao alterar senha:', error);

    return res.status(500).json({
      message: 'Erro interno no servidor ao alterar a senha.'
    });
  }
});


// --- DASHBOARD ---

const handleGetDashboard = async (req, res) => {
  try {
    // 1. Saldo total e alertas de estoque mínimo
    const [[{ totalProducts }]] = await db.query(
      'SELECT COALESCE(SUM(quantidade_atual), 0) AS totalProducts FROM estoque'
    );

    const [[{ lowStockCount }]] = await db.query(`
      SELECT COUNT(*) AS lowStockCount
      FROM estoque e
      JOIN produto p ON e.id_produto = p.id_produto
      WHERE e.quantidade_atual <= p.estoque_minimo
    `);

    // 2. Contagem dos 8 módulos (igual ao dashboard.html)
    const [[modulos]] = await db.query(`
      SELECT
        (SELECT COUNT(*) FROM produto) AS produtos,
        (SELECT COUNT(*) FROM estoque) AS estoque,
        (SELECT COUNT(*) FROM pedido_entrada) AS entradas,
        (SELECT COUNT(*) FROM pedido_saida) AS saidas,
        (SELECT COUNT(*) FROM usuarios) AS usuarios,
        (SELECT COUNT(*) FROM cadastro_sensor) AS sensores,
        (SELECT COUNT(*) FROM caminhao) AS caminhoes,
        (SELECT COUNT(*) FROM fornecedor) AS fornecedores
    `);

    // 3. Movimentações diárias (Entradas vs. Saídas)
    const [movimentacoesRows] = await db.query(`
      SELECT
        DATE_FORMAT(dia, '%d/%m') AS label,
        dia,
        SUM(entrada) AS entrada,
        SUM(saida) AS saida
      FROM (
        SELECT
          DATE(COALESCE(pe.data_entrada, pe.criado_em)) AS dia,
          COALESCE(SUM(ipe.quantidade), 0) AS entrada,
          0 AS saida
        FROM item_pedido_entrada ipe
        JOIN pedido_entrada pe
          ON ipe.id_pedido_entrada = pe.id_pedido_entrada
        GROUP BY DATE(COALESCE(pe.data_entrada, pe.criado_em))

        UNION ALL

        SELECT
          DATE(COALESCE(ps.data_saida, ps.criado_em)) AS dia,
          0 AS entrada,
          COALESCE(SUM(ips.quantidade), 0) AS saida
        FROM item_pedido_saida ips
        JOIN pedido_saida ps
          ON ips.id_pedido_saida = ps.id_pedido_saida
        GROUP BY DATE(COALESCE(ps.data_saida, ps.criado_em))
      ) AS movs
      WHERE dia IS NOT NULL
      GROUP BY dia, DATE_FORMAT(dia, '%d/%m')
      ORDER BY dia DESC
      LIMIT 6
    `);

    res.json({
      totalProducts: Number(totalProducts) || 0,
      lowStockCount: Number(lowStockCount) || 0,
      modulos: {
        produtos: Number(modulos.produtos) || 0,
        estoque: Number(modulos.estoque) || 0,
        entradas: Number(modulos.entradas) || 0,
        saidas: Number(modulos.saidas) || 0,
        usuarios: Number(modulos.usuarios) || 0,
        sensores: Number(modulos.sensores) || 0,
        caminhoes: Number(modulos.caminhoes) || 0,
        fornecedores: Number(modulos.fornecedores) || 0,
      },
      movimentacoesPorDia: movimentacoesRows.reverse(),
    });
  } catch (error) {
    console.error('Erro no dashboard:', error);
    res.status(500).json({ error: error.message });
  }
};

app.get('/api/dashboard', handleGetDashboard);
app.get('/dashboard', handleGetDashboard);

// INICIAR SERVIDOR
const PORT = process.env.PORT || 3000;

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Servidor rodando em http://0.0.0.0:${PORT}`);
});