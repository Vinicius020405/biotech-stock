import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Alert
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../src/context/ThemeContext';

export default function ForgotPasswordScreen({ navigation }) {
  const { theme, darkMode } = useTheme();

  // Etapas: 1 = Informar E-mail | 2 = Nova Senha
  const [step, setStep] = useState(1);

  const [email, setEmail] = useState('');
  const [novaSenha, setNovaSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');

  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState('');
  const [sucesso, setSucesso] = useState('');

  // IP igual ao utilizado no LoginScreen
  const API_URL = 'http://10.135.60.94:3000';

  // Etapa 1: Verificar e-mail
  async function handleVerificarEmail() {
    if (!email.trim()) {
      Alert.alert('Atenção', 'Por favor, digite o e-mail.');
      return;
    }

    setCarregando(true);
    setErro('');

    try {
      const response = await fetch(`${API_URL}/verificar-email`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim() }),
      });

      const data = await response.json();

      if (response.ok) {
        setStep(2);
      } else {
        setErro(data.message || 'E-mail não encontrado no sistema.');
      }
    } catch (error) {
      setErro('Erro de Conexão: Não foi possível conectar ao servidor.');
    } finally {
      setCarregando(false);
    }
  }

  // Etapa 2: Salvar nova senha
  async function handleRedefinirSenha() {
    if (!novaSenha.trim() || !confirmarSenha.trim()) {
      Alert.alert('Atenção', 'Preencha os campos de senha.');
      return;
    }

    if (novaSenha !== confirmarSenha) {
      setErro('As senhas não coincidem.');
      return;
    }

    setCarregando(true);
    setErro('');

    try {
      const response = await fetch(`${API_URL}/redefinir-senha`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: email.trim(),
          novaSenha: novaSenha.trim(),
        }),
      });

      const data = await response.json();

      if (response.ok) {
        setSucesso('Senha alterada com sucesso! Redirecionando...');
        setTimeout(() => {
          navigation.navigate('Login');
        }, 2000);
      } else {
        setErro(data.message || 'Não foi possível alterar a senha.');
      }
    } catch (error) {
      setErro('Erro de Conexão: Não foi possível salvar a nova senha.');
    } finally {
      setCarregando(false);
    }
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.bg }]}>
      
      {/* Botão Voltar */}
      <TouchableOpacity
        style={[
          styles.backBtn,
          { backgroundColor: theme.card, borderColor: theme.border }
        ]}
        onPress={() => {
          if (step === 2) {
            setStep(1);
            setErro('');
          } else {
            navigation.goBack();
          }
        }}
      >
        <Ionicons name="arrow-back" size={23} color={theme.textPrimary} />
      </TouchableOpacity>

      {/* Card Formulário */}
      <View style={[styles.card, { backgroundColor: theme.card, borderColor: theme.border }]}>
        
        <View style={styles.headerIconContainer}>
          <Ionicons 
            name={step === 1 ? "key-outline" : "lock-closed-outline"} 
            size={46} 
            color="#3B82F6" 
          />
        </View>

        <Text style={[styles.title, { color: theme.textPrimary }]}>
          {step === 1 ? 'Recuperar Senha' : 'Criar Nova Senha'}
        </Text>

        <Text style={[styles.subtitle, { color: theme.textSecondary }]}>
          {step === 1
            ? 'Informe seu e-mail cadastrado para redefinir a senha.'
            : `Digite a nova senha para a conta: ${email}`}
        </Text>

        {/* ETAPA 1: INPUT E-MAIL */}
        {step === 1 && (
          <View style={styles.inputGroup}>
            <Text style={[styles.label, { color: theme.textPrimary }]}>E-mail</Text>
            <View
              style={[
                styles.inputContainer,
                { backgroundColor: darkMode ? '#1E293B' : '#F1F5F9', borderColor: theme.border }
              ]}
            >
              <Ionicons name="mail-outline" size={20} color={theme.textSecondary} />
              <TextInput
                style={[styles.input, { color: theme.textPrimary }]}
                placeholder="Digite seu e-mail"
                placeholderTextColor={theme.textSecondary}
                keyboardType="email-address"
                autoCapitalize="none"
                value={email}
                onChangeText={setEmail}
              />
            </View>
          </View>
        )}

        {/* ETAPA 2: INPUTS NOVA SENHA */}
        {step === 2 && (
          <>
            <View style={styles.inputGroup}>
              <Text style={[styles.label, { color: theme.textPrimary }]}>Nova Senha</Text>
              <View
                style={[
                  styles.inputContainer,
                  { backgroundColor: darkMode ? '#1E293B' : '#F1F5F9', borderColor: theme.border }
                ]}
              >
                <Ionicons name="lock-closed-outline" size={20} color={theme.textSecondary} />
                <TextInput
                  style={[styles.input, { color: theme.textPrimary }]}
                  placeholder="Digite a nova senha"
                  placeholderTextColor={theme.textSecondary}
                  secureTextEntry
                  value={novaSenha}
                  onChangeText={setNovaSenha}
                />
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={[styles.label, { color: theme.textPrimary }]}>Confirmar Nova Senha</Text>
              <View
                style={[
                  styles.inputContainer,
                  { backgroundColor: darkMode ? '#1E293B' : '#F1F5F9', borderColor: theme.border }
                ]}
              >
                <Ionicons name="shield-checkmark-outline" size={20} color={theme.textSecondary} />
                <TextInput
                  style={[styles.input, { color: theme.textPrimary }]}
                  placeholder="Confirme a nova senha"
                  placeholderTextColor={theme.textSecondary}
                  secureTextEntry
                  value={confirmarSenha}
                  onChangeText={setConfirmarSenha}
                />
              </View>
            </View>
          </>
        )}

        {/* MENSAGENS DE ERRO E SUCESSO */}
        {erro !== '' && (
          <View style={styles.errorBox}>
            <Ionicons name="alert-circle-outline" size={20} color="#EF4444" />
            <Text style={styles.errorText}>{erro}</Text>
          </View>
        )}

        {sucesso !== '' && (
          <View style={styles.successBox}>
            <Ionicons name="checkmark-circle-outline" size={20} color="#22C55E" />
            <Text style={styles.successText}>{sucesso}</Text>
          </View>
        )}

        {/* BOTÃO DE AÇÃO */}
        <TouchableOpacity
          style={[styles.button, carregando && { opacity: 0.7 }]}
          onPress={step === 1 ? handleVerificarEmail : handleRedefinirSenha}
          disabled={carregando}
        >
          {carregando ? (
            <ActivityIndicator color="#FFFFFF" />
          ) : (
            <Text style={styles.buttonText}>
              {step === 1 ? 'Continuar' : 'Salvar Nova Senha'}
            </Text>
          )}
        </TouchableOpacity>

        {/* LINK VOLTAR AO LOGIN */}
        <TouchableOpacity
          style={styles.loginLink}
          onPress={() => navigation.navigate('Login')}
        >
          <Text style={[styles.loginLinkText, { color: theme.textSecondary }]}>
            Lembrou a senha? <Text style={{ color: '#3B82F6', fontWeight: '700' }}>Fazer Login</Text>
          </Text>
        </TouchableOpacity>

      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    justifyContent: 'center',
  },
  backBtn: {
    position: 'absolute',
    top: 50,
    left: 20,
    width: 44,
    height: 44,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    zIndex: 10,
  },
  card: {
    borderRadius: 24,
    padding: 24,
    borderWidth: 1,
  },
  headerIconContainer: {
    alignItems: 'center',
    marginBottom: 14,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 6,
  },
  subtitle: {
    fontSize: 13,
    textAlign: 'center',
    lineHeight: 18,
    marginBottom: 20,
  },
  inputGroup: {
    marginBottom: 14,
  },
  label: {
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 6,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 50,
    borderRadius: 14,
    paddingHorizontal: 14,
    borderWidth: 1,
  },
  input: {
    flex: 1,
    marginLeft: 10,
    fontSize: 14,
  },
  button: {
    backgroundColor: '#3B82F6',
    height: 50,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '700',
  },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    padding: 10,
    borderRadius: 12,
    marginBottom: 12,
    gap: 8,
  },
  errorText: {
    color: '#EF4444',
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
  },
  successBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(34, 197, 94, 0.1)',
    padding: 10,
    borderRadius: 12,
    marginBottom: 12,
    gap: 8,
  },
  successText: {
    color: '#22C55E',
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
  },
  loginLink: {
    marginTop: 18,
    alignItems: 'center',
  },
  loginLinkText: {
    fontSize: 13,
  },
});