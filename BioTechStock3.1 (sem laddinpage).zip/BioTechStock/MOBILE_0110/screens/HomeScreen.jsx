import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  StatusBar,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import api from '../src/services/api';
import { useTheme } from '../src/context/ThemeContext';

// "Há 15 min", "Há 2h", "Há 3 d" ou a data, para registros mais antigos
function tempoRelativo(valor) {
  if (!valor) return '';
  const data = new Date(valor);
  if (isNaN(data.getTime())) return '';

  const minutos = Math.floor((Date.now() - data.getTime()) / 60000);
  if (minutos < 1) return 'Agora';
  if (minutos < 60) return `Há ${minutos} min`;

  const horas = Math.floor(minutos / 60);
  if (horas < 24) return `Há ${horas}h`;

  const dias = Math.floor(horas / 24);
  if (dias < 7) return `Há ${dias} d`;

  return data.toLocaleDateString('pt-BR');
}

export default function HomeScreen({ navigation }) {
  const { theme, darkMode } = useTheme();

  const [nomeUsuario, setNomeUsuario] = useState('');
  const [resumo, setResumo] = useState({
    totalProducts: 0,
    lowStockCount: 0,
    sensoresInativos: 0,
  });
  const [movimentacoes, setMovimentacoes] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [erro, setErro] = useState('');

  const carregarDados = async () => {
    try {
      setErro('');

      // Usuário logado (guardado pelo LoginScreen)
      const salvo = await AsyncStorage.getItem('@user_data');
      if (salvo) {
        const user = JSON.parse(salvo);
        const nome = user.nome || user.name || '';
        setNomeUsuario(nome.trim().split(' ')[0]);
      }

      // allSettled: se uma rota falhar, as outras continuam aparecendo
      const [dashboard, historico, sensores] = await Promise.allSettled([
        api.get('/dashboard'),
        api.get('/history'),
        api.get('/sensores'),
      ]);

      if (dashboard.status === 'fulfilled') {
        setResumo((atual) => ({
          ...atual,
          totalProducts: Number(dashboard.value.data.totalProducts) || 0,
          lowStockCount: Number(dashboard.value.data.lowStockCount) || 0,
        }));
      }

      if (sensores.status === 'fulfilled' && Array.isArray(sensores.value.data)) {
        const inativos = sensores.value.data.filter(
          (s) => (s.status || '').toLowerCase() !== 'ativo'
        ).length;
        setResumo((atual) => ({ ...atual, sensoresInativos: inativos }));
      }

      if (historico.status === 'fulfilled' && Array.isArray(historico.value.data)) {
        setMovimentacoes(historico.value.data.slice(0, 3));
      }

      if (
        dashboard.status === 'rejected' &&
        historico.status === 'rejected' &&
        sensores.status === 'rejected'
      ) {
        setErro('Não foi possível conectar ao servidor. Puxe para baixo para tentar de novo.');
      }
    } catch (error) {
      setErro('Não foi possível carregar os dados.');
    } finally {
      setCarregando(false);
      setRefreshing(false);
    }
  };

  // Recarrega sempre que a Home volta ao foco (ex.: depois de registrar uma entrada)
  useFocusEffect(
    useCallback(() => {
      carregarDados();
    }, [])
  );

  const onRefresh = () => {
    setRefreshing(true);
    carregarDados();
  };

  const quickAccessItems = [
    { title: 'Estoque', subtitle: 'Quantidade em estoque', icon: 'layers', screen: 'Estoque' },
    { title: 'Localizações', subtitle: 'Setores e Prateleiras', icon: 'location', screen: 'LocationScreen' },
    { title: 'Sensores', subtitle: 'Dispositivos e Status', icon: 'hardware-chip', screen: 'SensorsScreens' },
    { title: 'Fornecedores', subtitle: 'Empresas fornecedoras', icon: 'business', screen: 'FornecedoresScreens' },
    { title: 'Caminhões', subtitle: 'Frota de Transporte', icon: 'bus', screen: 'CaminhaoScreen' },
    { title: 'Produtos', subtitle: 'Cadastro de Itens', icon: 'cube', screen: 'ProductsScreens' },
    { title: 'Histórico', subtitle: 'Entradas e Saídas', icon: 'time', screen: 'Histórico' },
    { title: 'Ajustes', subtitle: 'Configurações', icon: 'settings', screen: 'SettingsScreen' },
  ];

  const estatisticas = [
    {
      label: 'Itens em estoque',
      valor: resumo.totalProducts,
      icon: 'layers',
      cor: '#3B82F6',
      fundo: 'rgba(59, 130, 246, 0.15)',
      destino: 'Estoque',
    },
    {
      label: 'Abaixo do mínimo',
      valor: resumo.lowStockCount,
      icon: 'warning',
      cor: resumo.lowStockCount > 0 ? '#EF4444' : '#22C55E',
      fundo: resumo.lowStockCount > 0 ? 'rgba(239, 68, 68, 0.15)' : 'rgba(34, 197, 94, 0.15)',
      destino: 'Estoque',
    },
    {
      label: 'Sensores inativos',
      valor: resumo.sensoresInativos,
      icon: 'hardware-chip',
      cor: resumo.sensoresInativos > 0 ? '#F97316' : '#22C55E',
      fundo: resumo.sensoresInativos > 0 ? 'rgba(249, 115, 22, 0.15)' : 'rgba(34, 197, 94, 0.15)',
      destino: 'SensorsScreens',
    },
  ];

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: theme.bg }]}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#3B82F6" />
      }
    >
      <StatusBar barStyle={darkMode ? 'light-content' : 'dark-content'} />

      {/* HEADER */}
      <View style={styles.header}>
        <View style={{ flex: 1 }}>
          <Text style={[styles.welcomeText, { color: theme.textSecondary }]}>
            {nomeUsuario ? `Bem-vindo, ${nomeUsuario}` : 'Bem-vindo'}
          </Text>
          <Text style={[styles.headerTitle, { color: theme.textPrimary }]}>
            Sistema de Estoque
          </Text>
        </View>

        <TouchableOpacity
          style={[styles.qrButton, { backgroundColor: theme.card }]}
          accessibilityLabel="Escanear código do produto"
        >
          <Ionicons name="qr-code-outline" size={24} color="#3B82F6" />
        </TouchableOpacity>
      </View>

      {/* ERRO DE CONEXÃO */}
      {erro !== '' && (
        <View style={styles.errorBox}>
          <Ionicons name="alert-circle-outline" size={20} color="#EF4444" />
          <Text style={styles.errorText}>{erro}</Text>
        </View>
      )}

      {/* RESUMO */}
      <View style={styles.statsRow}>
        {estatisticas.map((item) => (
          <TouchableOpacity
            key={item.label}
            style={[styles.statCard, { backgroundColor: theme.card }]}
            onPress={() => navigation.navigate(item.destino)}
            activeOpacity={0.7}
          >
            <View style={[styles.statIcon, { backgroundColor: item.fundo }]}>
              <Ionicons name={item.icon} size={16} color={item.cor} />
            </View>
            {carregando ? (
              <ActivityIndicator size="small" color="#3B82F6" style={styles.statLoading} />
            ) : (
              <Text style={[styles.statValue, { color: item.cor }]}>{item.valor}</Text>
            )}
            <Text style={[styles.statLabel, { color: theme.textSecondary }]} numberOfLines={2}>
              {item.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* ACESSO RÁPIDO */}
      <Text style={[styles.sectionTitle, { color: theme.textPrimary }]}>Acesso Rápido</Text>

      <View style={styles.gridContainer}>
        {quickAccessItems.map((item) => (
          <TouchableOpacity
            key={item.title}
            style={[styles.gridCard, { backgroundColor: theme.card }]}
            onPress={() => navigation.navigate(item.screen)}
            activeOpacity={0.7}
          >
            <View style={[styles.iconBox, { backgroundColor: 'rgba(59, 130, 246, 0.15)' }]}>
              <Ionicons name={item.icon} size={22} color="#3B82F6" />
            </View>
            <Text style={[styles.cardTitle, { color: theme.textPrimary }]}>{item.title}</Text>
            <Text style={[styles.cardSubtitle, { color: theme.textSecondary }]}>
              {item.subtitle}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* ÚLTIMAS MOVIMENTAÇÕES */}
      <View style={styles.sectionHeader}>
        <Text style={[styles.sectionTitle, { color: theme.textPrimary, marginBottom: 0 }]}>
          Últimas Movimentações
        </Text>
        <TouchableOpacity onPress={() => navigation.navigate('Histórico')}>
          <Text style={styles.seeAllText}>Ver tudo</Text>
        </TouchableOpacity>
      </View>

      <View style={[styles.movementCard, { backgroundColor: theme.card }]}>
        {carregando ? (
          <ActivityIndicator color="#3B82F6" style={{ paddingVertical: 20 }} />
        ) : movimentacoes.length === 0 ? (
          <View style={styles.emptyBox}>
            <Ionicons name="time-outline" size={32} color={theme.textSecondary} />
            <Text style={[styles.emptyText, { color: theme.textSecondary }]}>
              Nenhuma movimentação registrada ainda. Use as abas Entrada e Saída para começar.
            </Text>
          </View>
        ) : (
          movimentacoes.map((mov, index) => {
            const isEntrada = (mov.type || '').toLowerCase().includes('entrada');
            return (
              <View key={mov.id ?? index}>
                {index > 0 && <View style={[styles.divider, { backgroundColor: theme.border }]} />}
                <View style={styles.movementItem}>
                  <View
                    style={[
                      styles.movementIcon,
                      {
                        backgroundColor: isEntrada
                          ? 'rgba(34, 197, 94, 0.15)'
                          : 'rgba(239, 68, 68, 0.15)',
                      },
                    ]}
                  >
                    <Ionicons
                      name={isEntrada ? 'arrow-down-circle' : 'arrow-up-circle'}
                      size={22}
                      color={isEntrada ? '#22C55E' : '#EF4444'}
                    />
                  </View>
                  <View style={styles.movementDetails}>
                    <Text style={[styles.movementTitle, { color: theme.textPrimary }]}>
                      {isEntrada ? 'Entrada de Material' : 'Saída de Estoque'}
                    </Text>
                    <Text
                      style={[styles.movementSubtitle, { color: theme.textSecondary }]}
                      numberOfLines={1}
                    >
                      {mov.quantidade}x {mov.product || 'Produto'}
                    </Text>
                  </View>
                  <Text style={[styles.movementTime, { color: theme.textSecondary }]}>
                    {tempoRelativo(mov.created_at || mov.date)}
                  </Text>
                </View>
              </View>
            );
          })
        )}
      </View>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
  },
  header: {
    marginTop: 55,
    marginBottom: 22,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  welcomeText: {
    fontSize: 14,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 2,
  },
  qrButton: {
    width: 48,
    height: 48,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    padding: 12,
    borderRadius: 12,
    marginBottom: 16,
    gap: 8,
  },
  errorText: {
    color: '#EF4444',
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 26,
    gap: 10,
  },
  statCard: {
    flex: 1,
    borderRadius: 18,
    padding: 14,
  },
  statIcon: {
    width: 30,
    height: 30,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },
  statValue: {
    fontSize: 26,
    fontWeight: '800',
  },
  statLoading: {
    alignSelf: 'flex-start',
    height: 31,
  },
  statLabel: {
    fontSize: 12,
    marginTop: 2,
    lineHeight: 15,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  gridCard: {
    width: '48%',
    borderRadius: 20,
    padding: 18,
    marginBottom: 15,
  },
  iconBox: {
    width: 42,
    height: 42,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 14,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  cardSubtitle: {
    fontSize: 13,
    marginTop: 4,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 15,
  },
  seeAllText: {
    color: '#3B82F6',
    fontSize: 14,
    fontWeight: '600',
  },
  movementCard: {
    borderRadius: 20,
    padding: 16,
    marginTop: 14,
  },
  movementItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  movementIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  movementDetails: {
    flex: 1,
    marginLeft: 12,
    marginRight: 8,
  },
  movementTitle: {
    fontSize: 15,
    fontWeight: 'bold',
  },
  movementSubtitle: {
    fontSize: 13,
    marginTop: 2,
  },
  movementTime: {
    fontSize: 12,
  },
  divider: {
    height: 1,
    marginVertical: 14,
  },
  emptyBox: {
    alignItems: 'center',
    paddingVertical: 14,
    gap: 8,
  },
  emptyText: {
    fontSize: 13,
    textAlign: 'center',
    lineHeight: 18,
  },
});