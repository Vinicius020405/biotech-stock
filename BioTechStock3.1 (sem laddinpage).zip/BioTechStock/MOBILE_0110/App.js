import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

import { ThemeProvider, useTheme } from './src/context/ThemeContext';

import HomeScreen from './screens/HomeScreen';
import StockScreens from './screens/StockScreen';
import EntryScreen from './screens/EntryScreen';
import ExitScreen from './screens/ExitScreen';
import HistoryScreen from './screens/HistoryScreen';

import LoginScreen from './screens/LoginScreen';
import ForgotPasswordScreen from './screens/ForgotPasswordScreen';
import LocationScreen from './screens/LocationScreen';
import SensorsScreens from './screens/SensoresScreen';
import FornecedoresScreens from './screens/FornecedoresScreen';
import CaminhaoScreen from './screens/CaminhoesScreen';
import SettingsScreen from './screens/SettingsScreen';
import ProductsScreens from './screens/ProductsScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function TabNavigator() {
  const { theme, darkMode } = useTheme();
  const insets = useSafeAreaInsets();

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarShowLabel: true,
        tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
        tabBarActiveTintColor: '#3B82F6',
        tabBarInactiveTintColor: darkMode ? '#94A3B8' : '#64748B',
        tabBarStyle: {
          backgroundColor: theme.card,
          borderTopWidth: 1,
          borderTopColor: theme.border,
          height: 60 + insets.bottom,
          paddingBottom: insets.bottom + 6,
          paddingTop: 6,
        },
        tabBarIcon: ({ focused, color }) => {
          const icons = {
            Home: focused ? 'home' : 'home-outline',
            Estoque: focused ? 'layers' : 'layers-outline',
            Entrada: focused ? 'arrow-down-circle' : 'arrow-down-circle-outline',
            Saída: focused ? 'arrow-up-circle' : 'arrow-up-circle-outline',
            Histórico: focused ? 'time' : 'time-outline',
          };
          const iconName = icons[route.name] || 'alert-circle-outline';

          return <Ionicons name={iconName} size={22} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Estoque" component={StockScreens} />
      <Tab.Screen name="Entrada" component={EntryScreen} />
      <Tab.Screen name="Saída" component={ExitScreen} />
      <Tab.Screen name="Histórico" component={HistoryScreen} />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <NavigationContainer>
          <Stack.Navigator
            screenOptions={{ headerShown: false }}
            initialRouteName="Login"
          >
            <Stack.Screen name="Login" component={LoginScreen} />
            <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
            <Stack.Screen name="MainApp" component={TabNavigator} />
            <Stack.Screen name="LocationScreen" component={LocationScreen} />
            <Stack.Screen name="SensorsScreens" component={SensorsScreens} />
            <Stack.Screen name="CaminhaoScreen" component={CaminhaoScreen} />
            <Stack.Screen name="SettingsScreen" component={SettingsScreen} />
            <Stack.Screen name="ProductsScreens" component={ProductsScreens} />
            <Stack.Screen name="FornecedoresScreens" component={FornecedoresScreens} />
            <Stack.Screen name="StockScreens" component={StockScreens} />
          </Stack.Navigator>
        </NavigationContainer>
      </ThemeProvider>
    </SafeAreaProvider>
  );
}